## GENE: [NAME]

**ID:** GENE-001  
**Discovered:** 2026-XX-XX  
**Source Artifact:** [filename.zip]  
**Harness Result:** SURVIVOR_PHASE_0  
**Tests Passed:** T0, T1, T2, T3, T4

### Rule
[Core invariant - the "law" this gene enforces]

### Enforcement
[How to implement in production systems]

### Test Protocol
[How to verify this gene is working]

### Integration Status
- [ ] Documented
- [ ] Reviewed
- [ ] Integrated into helios_watcher.py
- [ ] Verified in production

### Notes
[Additional observations]
