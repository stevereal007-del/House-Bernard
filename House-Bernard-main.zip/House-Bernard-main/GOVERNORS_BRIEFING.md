# GOVERNOR'S BRIEFING — February 10, 2026

**Read this first, Claude Code. Then read CLAUDE.md. Then read TONIGHTS_BUILD.md.**

---

## WHAT JUST HAPPENED

The Governor spent tonight's planning session making three major decisions
and building the backend to support them. Here's what changed and why.

### Decision 1: Solana, not Ethereum

$HOUSEBERNARD is an SPL token on Solana mainnet. Not ERC-20. Not Base.
The reasons:

- SPL tokens use Solana's built-in Token Program — no custom smart contract
- No smart contract means no $2,000-10,000 audit bill
- Creating the token is 4 CLI commands, not a Hardhat project
- Transfers cost $0.00025, not $2-10
- Monthly blockchain cost: < $0.10 vs hundreds on Ethereum L1
- The Governor has a $100 budget for tonight. Solana respects that.

Constitutional constraints (vesting, emission caps, burn rates, sale
limits) are enforced by treasury_engine.py — not the token contract.
The token is dumb money. The governance layer is smart. Separation
of concerns.

### Decision 2: 60/15/15/10 allocation (TREASURY.md is canonical)

There was a conflict between TREASURY.md and SOVEREIGN_ECONOMICS.md.
It's resolved. TREASURY.md wins. The canonical genesis distribution:

| Allocation | % | Tokens | Wallet File |
|------------|---|--------|-------------|
| Unmined Treasury | 60% | 60,000,000 | ~/hb-unmined-treasury.json |
| Liquidity Pool | 15% | 15,000,000 | Raydium AMM pool |
| Governor Reserve | 15% | 15,000,000 | ~/hb-governor-reserve.json |
| Genesis Contributors | 10% | 10,000,000 | ~/hb-genesis-contributors.json |

Founder vesting, Bernard Trust, and all contributor payments come
FROM the 60M Unmined Treasury through documented constitutional
mechanisms. They are not separate genesis allocations.

SOVEREIGN_ECONOMICS.md Section IV has been updated to match.
If you ever see a conflict between these two documents, TREASURY.md
is the authority.

### Decision 3: Autonomous backend — the Governor doesn't sign checks

The Governor works nights at Pratt & Whitney inspecting turbine
blades. He doesn't have time to manually approve every bounty
payment. The backend runs itself:

```
Contributor survives Furnace
  → executioner_production.py verdict: SURVIVOR_PHASE_0
  → treasury_engine.record_base_payment()
      validates amount, enforces epoch cap, computes 5% burn
  → solana_dispatcher.pay()
      executes spl-token transfer on Solana mainnet
      captures USD fair market value from Jupiter API
      logs intent + receipt to dispatch_log.jsonl
  → cpa_agent.record_payment()
      records tax-relevant data
      tracks contributor's yearly USD total
      flags when approaching $600 (1099-NEC threshold)
  → Done. No human touched it.
```

Three new files make this work:

**treasury/solana_dispatcher.py** — Wraps the Solana CLI. Executes
transfers from constitutional wallets. Features:
- Kill switch (create PAUSE file to halt all transfers)
- Rate limiting (max single transfer, max daily total)
- Retry queue for failed transactions
- USD price capture at time of every transfer
- Batch payment mode for monthly royalty/bond disbursements
- Append-only dispatch log (immutable audit trail)

**treasury/cpa_agent.py** — The Finance Director. Features:
- Records every successful payment with USD fair market value
- Tracks per-contributor yearly totals
- Flags 1099-NEC threshold ($600) automatically
- Warns at 80% of threshold (approaching)
- Generates yearly Schedule C data for Governor's tax filing
- Generates quarterly audit reports for Wardens
- Logs business expenses (hardware, software, legal, etc.)

**treasury/test_backend.py** — 10 tests validating the pipeline:
- CPA records payments correctly
- 1099 threshold detection works
- Approaching-threshold warnings work
- Failed payments are not recorded in tax ledger
- Expense recording works
- Yearly report generation works
- Multiple contributors tracked independently
- Dispatcher config template validates
- Kill switch works
- Engine → CPA integration pipeline works

All 10 pass. Combined with existing tests: 122/122 total (61 treasury
engine + 51 monthly ops + 10 backend).

---

## WHAT TO DO TONIGHT

Read TONIGHTS_BUILD.md. It has 8 phases, ~95 minutes total, ~$100.

**Short version:**
1. Unpack this repo update, validate OPSEC, commit, push
2. Install Solana CLI on the Beelink
3. Create wallet, buy 5 SOL (~$110), send to wallet
4. Create $HOUSEBERNARD token (4 commands)
5. Upload metadata (name, symbol, logo)
6. Create Raydium liquidity pool (15M tokens + 3-5 SOL)
7. Create allocation wallets, distribute 60/15/15/10
8. Park social handles

**After token is deployed**, run:
```bash
cd ~/House-Bernard/treasury
python3 solana_dispatcher.py init
```
This creates dispatcher_config.json. Fill in the mint address and
wallet addresses from the deployment. This connects the payment
pipeline to the real blockchain.

---

## WHAT TO BUILD NEXT SESSION

The backend is wired. The token will be live. What's missing is the
trigger — the connection between Executioner verdicts and automatic
payments. Build order:

1. **Wire Executioner → Dispatcher**: When executioner_production.py
   produces a SURVIVOR_PHASE_0 verdict, it should call
   treasury_engine.record_base_payment() and then
   solana_dispatcher.pay(). This is a ~20 line integration in
   executioner_production.py.

2. **Wire monthly_ops.py → Dispatcher**: monthly_ops.py currently
   computes royalties and bond yields but doesn't disburse. Add
   solana_dispatcher.pay_batch() calls after computing obligations.
   The monthly_ops.py cron job then handles everything automatically
   on the 1st of each month.

3. **Contributor onboarding flow**: A new contributor needs a Solana
   wallet. Build a simple onboarding script that:
   - Asks for their Phantom wallet address
   - Registers them in the contributor directory
   - Creates their entry in the CPA Agent ledger
   - Sends them a test payment (1 $HOUSEBERNARD) to verify the address

4. **OpenClaw frontend**: This is LAST. The backend runs without it.
   OpenClaw is the public face — contributor portal, brief submission,
   Furnace status, governance dashboard. Build it on top of everything
   that's already working.

---

## FILE MAP AFTER TONIGHT

```
~/House-Bernard/
├── CLAUDE.md                    ← YOU READ THIS FIRST
├── TONIGHTS_BUILD.md            ← DEPLOYMENT PLAYBOOK
├── CONSTITUTION.md              ← 11 articles
├── TREASURY.md                  ← CANONICAL allocation authority
├── SOVEREIGN_ECONOMICS.md       ← Reconciled to match TREASURY.md
├── ROYALTIES.md                 ← Tier system + decay mechanics
├── legal/
│   ├── OPERATING_AGREEMENT.md
│   ├── TOKEN_TERMS_OF_SERVICE.md
│   └── TRADEMARK_GUIDE.md
├── token/                       ← Created during tonight's build
│   ├── TOKEN_RECORD.md
│   ├── metadata.json
│   └── logo.png
├── treasury/
│   ├── treasury_engine.py       ← Core economics (61 tests)
│   ├── treasury_cli.py          ← Manual operations CLI
│   ├── monthly_ops.py           ← Automated cron job (51 tests)
│   ├── solana_dispatcher.py     ← On-chain payments (NEW)
│   ├── cpa_agent.py             ← Tax compliance (NEW)
│   ├── test_backend.py          ← Backend tests (NEW, 10 tests)
│   ├── treasury_state.json      ← Financial state
│   ├── ops_state.json           ← Operations state
│   ├── redteam_test.py          ← Treasury red team
│   └── redteam_monthly_ops.py   ← Monthly ops red team
├── executioner/                 ← Selection Furnace
├── splicer/                     ← Gene extraction
├── airlock/                     ← Submission intake
├── ledger/                      ← Outcome records
├── lab_b/                       ← Security genetics lab
├── security/                    ← AST scanner, seccomp
├── section_9/                   ← CLASSIFIED
├── openclaw/                    ← Frontend (BUILD LAST)
└── infrastructure/              ← Deployment configs

~/house-bernard-wallet.json      ← Main wallet (NEVER commit)
~/hb-unmined-treasury.json       ← 60M treasury (NEVER commit)
~/hb-governor-reserve.json       ← 15M reserve (NEVER commit)
~/hb-genesis-contributors.json   ← 10M genesis (NEVER commit)
```

---

## TEST COMMANDS

```bash
# Run all tests
cd ~/House-Bernard/treasury
python3 redteam_test.py          # 61 treasury engine tests
python3 redteam_monthly_ops.py   # 51 monthly ops tests
python3 test_backend.py          # 10 backend integration tests
# Total: 122 tests, all must pass

# Check balances (after token deployment)
python3 solana_dispatcher.py balance

# Check tax status
python3 cpa_agent.py status

# Monthly treasury report
python3 treasury_cli.py report
```

---

*Classification: GOVERNOR EYES ONLY*
*House Bernard — Ad Astra Per Aspera*
