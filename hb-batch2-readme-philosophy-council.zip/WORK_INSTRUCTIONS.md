# WORK INSTRUCTIONS — Batch 2: README.md Fix + PHILOSOPHY.md / COUNCIL.md Audit

## Context
Red team audit of House Bernard repo. This batch fixes the 6 README.md findings from Batch 1 and audits PHILOSOPHY.md and COUNCIL.md.

## Files Changed

### 1. README.md — REPLACE ENTIRELY
Copy `README.md` from this package over the existing file. All 6 findings are resolved:

| # | Finding | Fix Applied |
|---|---------|-------------|
| 1 | BUG: "T1–T6" should be T0–T4 | Changed to "T0–T4" (line 19) |
| 2 | BUG: 3 missing directories | Added /security, /infrastructure, /lab_b (lines 23-25) |
| 3 | STALE: "TURN: 48" footer | Removed. Footer now reads `[STATUS: GREEN \| SIGNED: THE GOVERNOR]` |
| 4 | UNDEFINED: SAIF v1.1 no spec | Added Section V with full contract table (lines 37-47) |
| 5 | MISSING: No QUICKSTART.md link | Added "New here?" link (line 51) |
| 6 | MINOR: No governance doc links | Added governance doc links in Section IV (line 35) |

### 2. House-Bernard-main.zip — DELETE
Stale zip in repo root. Already covered by `*.zip` in .gitignore but was committed before the rule existed.

```bash
git rm House-Bernard-main.zip
git commit -m "chore: remove stale zip from repo root"
```

### 3. PHILOSOPHY.md — NO CHANGES
Passed red team. 0 bugs. 2 advisory notes (see FINDINGS_PHILOSOPHY.md).

### 4. COUNCIL.md — NO CHANGES
Passed red team. 0 bugs found in this file. 1 stale cross-reference traced to ROYALTIES.md (will be fixed when ROYALTIES.md is audited). 1 advisory re: TBD wallet addresses.

## Git Commands

```bash
# Apply README fix
cp README.md /path/to/House-Bernard/README.md

# Remove stale zip
cd /path/to/House-Bernard
git rm House-Bernard-main.zip

# Commit
git add README.md
git commit -m "fix(readme): resolve 6 red team findings — test levels, missing dirs, SAIF spec, links

- Fix T1-T6 → T0-T4 (matches executioner_production.py)
- Add /security, /infrastructure, /lab_b to Sovereign Domains
- Remove stale TURN:48 footer artifact
- Add SAIF v1.1 contract spec (Section V)
- Add QUICKSTART.md link for new readers
- Add governance document links (COUNCIL, TREASURY, ROYALTIES, DEFENSE, PHILOSOPHY)
- Delete stale House-Bernard-main.zip from repo root"
```

## Audit Progress After This Batch

| File | Status |
|------|--------|
| README.md | ✅ FIXED (6/6 findings resolved) |
| PHILOSOPHY.md | ✅ CLEAN (0 fixes needed) |
| COUNCIL.md | ✅ CLEAN (0 fixes needed in this file) |
| TREASURY.md | ✅ CLEAN (from Batch 1 — 61/61 pass) |
| ROYALTIES.md | ⏳ NEXT — known issue: T3/T5/T6 test level mapping |
| DEFENSE.md | ⏳ PENDING |
| QUICKSTART.md | ⏳ PENDING — known issue: line 128 references T5 |
| .gitignore | ⏳ PENDING |
| airlock/ | ⏳ PENDING |
| executioner/ | ⏳ PENDING |
| splicer/ | ⏳ PENDING |
| ledger/ | ⏳ PENDING |
| openclaw/ | ⏳ PENDING |
| treasury/ | ✅ DONE (Batch 1) |
| security/ | ⏳ PENDING |
| infrastructure/ | ⏳ PENDING |
| lab_b/ | ⏳ PENDING |

## Known Cross-Cutting Bug (for ROYALTIES.md audit)

ROYALTIES.md maps contribution tiers to executioner test levels that don't exist:
- Spark → T3 (executioner only has T0–T4, so T3 exists but means "Compaction" not "Spark threshold")
- Flame → T5 (DOES NOT EXIST)
- Furnace-Forged → T6 (DOES NOT EXIST)
- QUICKSTART.md line 128 references "Phase 1 (T5 adversarial testing)" — also phantom

**Decision needed from Governor:** Are T5/T6 planned future test tiers, or should tier thresholds map to existing T0–T4 levels? This affects ROYALTIES.md, QUICKSTART.md, and TREASURY.md lines 79-81.
