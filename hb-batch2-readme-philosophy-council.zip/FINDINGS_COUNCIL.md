# Red Team Findings: COUNCIL.md

**Auditor:** Claude (Bernardian Council)
**Date:** 2025-02-08
**Verdict:** 2 findings (0 bugs, 1 stale ref, 1 advisory)

---

## Findings

### F1. STALE: Tier names reference phantom test levels via ROYALTIES.md (MEDIUM)

**Lines 121, 143, 184:** Reference "Flame tier or higher" and "Furnace-Forged/Invariant tiers" — these tier names are correct, but ROYALTIES.md maps them to T3/T5/T6 test levels that do not exist in the Executioner (which only has T0–T4).

COUNCIL.md itself is clean — it references tier *names*, not test *numbers*. But since it sends readers to ROYALTIES.md (line 253), the inconsistency propagates.

**Action:** No fix in COUNCIL.md. This is a ROYALTIES.md bug (will be flagged there). COUNCIL.md's tier name references are correct as-is.

### F2. ADVISORY: Governor wallet "TBD" in 3 places (LOW)

**Lines 53, 287:** Governor wallet listed as "TBD." This is fine for pre-deployment, but should be updated when the chain is selected and the wallet is created.

**Action:** No fix now. Flag for post-deployment checklist.

---

## Cross-Reference Checks Passed

| Claim | Verified Against |
|-------|-----------------|
| Council stake: 10,000 $HOUSEBERNARD | TREASURY.md line 125 (confirmed) |
| HeliosBlade as Governor | HB_STATE.json, TREASURY.md, AGENT_SPEC.md |
| Governor cannot be removed | AGENT_SPEC.md line 589 ("NOT a DAO. The Governor has final authority.") |
| Royalty termination on ban | Consistent with ROYALTIES.md royalty stream design |
| Council max 9 members | Only defined here — no contradiction elsewhere |
| Supermajority = 66% | Only defined here — no contradiction elsewhere |

## Structural Review

| Check | Result |
|-------|--------|
| Internal consistency | ✅ All sections reference each other correctly |
| Governance diagram matches prose | ✅ Three-tier structure (Governor → Council → Contributors) |
| Removal process covers all severity levels | ✅ Low/Medium vs High/Critical paths defined |
| Succession plan exists | ✅ Lines 88–94 |
| Open questions honestly documented | ✅ Lines 305–315 |
| Amendment process defined | ✅ Line 321 |
