# Section 9

Section 9 is governed by the Crown under classified authority,
as defined in the Constitution (Article I, Article IV Section 7).

For public security matters, see [DEFENSE.md](../DEFENSE.md).
For the Warden service, see the Constitution Article IV.

-----

*[STATUS: CLASSIFIED | AUTHORITY: THE CROWN]*
