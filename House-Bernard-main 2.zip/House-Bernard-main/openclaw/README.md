# House Bernard — AchillesRun Agent

## What This Is

AchillesRun is House Bernard deployed as an OpenClaw agent. OpenClaw is the body — gateway, channels, sessions, cron. House Bernard is the mind — what to trust, what to kill, what to remember, what to forget.

The Beelink EQ13 runs the OpenClaw gateway. AchillesRun runs inside it. The Crown communicates via Google Chat DM and Spaces (Phase 0) or Discord (Phase 1 fallback).

## Files

| File | Purpose |
|------|---------|
| `AGENT_SPEC.md` | The law governing AchillesRun's behavior, model selection, layers, memory, and security |
| `SOUL.md` | OpenClaw system prompt — AchillesRun's identity and operating principles |
| `openclaw.json` | OpenClaw configuration — models, channels, sessions, memory, cron, budget |
| `build.py` | Static dashboard builder (reads HB_STATE.json, outputs HTML) |
| `templates/` | HTML templates for the dashboard |

## Architecture Mapping

| House Bernard Concept | OpenClaw Implementation |
|----------------------|------------------------|
| Bicameral Mind (Worker/Master/Watcher/Oracle/Apex) | OpenClaw model config with Ollama aliases |
| Ring System (Commons/Yard/Workshop/Sanctum) | OpenClaw workspace directories + Google Chat Spaces |
| Session Persistence (Berman Pattern) | 365-day session expiration, no daily reset |
| Memory (MEMORY.md + daily logs + transcripts) | QMD backend, local sqlite-vec search, memory flush before compaction |
| Selection Furnace | OpenClaw skills running Airlock→Executioner→Splicer |
| Monthly Ops | OpenClaw cron job (1st of month, 6am UTC) |
| Heartbeat / Watcher | OpenClaw heartbeat config (30min, Llama 3.2:3b) |
| Crown Contact | Google Chat DM + Spaces (Phase 0), Discord fallback (Phase 1) |
| Session Isolation | OpenClaw `dmScope: per-channel-peer` |
| Swarm (Phase 2) | OpenClaw multi-agent routing |

## Quick Start

```bash
# On the Beelink:
cd ~/House-Bernard/infrastructure/deployment
chmod +x deploy_achillesrun.sh
./deploy_achillesrun.sh

# Then:
export ANTHROPIC_API_KEY='your-key'
export GOOGLE_CHAT_SERVICE_ACCOUNT_FILE='path-to-sa.json'
export GOOGLE_CHAT_WEBHOOK_URL='your-chat-app-url'
export GOVERNOR_GMAIL='your-gmail@gmail.com'
openclaw onboard

# Run security audit:
openclaw security audit --deep
```

## Channels

**Phase 0 (now):** Google Chat DM + Spaces — Crown only, allowlist enforced ($7/mo Workspace Starter).
**Phase 1:** Discord — free fallback if Google Chat has issues.

## Key Memory Files

| File | Purpose | Persistence |
|------|---------|-------------|
| `MEMORY.md` | Long-term curated facts | Permanent, private sessions only |
| `memory/YYYY-MM-DD.md` | Daily append-only logs | Rolling, today + yesterday loaded |
| `sessions/YYYY-MM-DD-slug.md` | Conversation transcripts | Searchable via memory_search |
| `TOOLS.md` | Tool configurations and capabilities | Permanent |

---

*House Bernard — Research Without Permission*
