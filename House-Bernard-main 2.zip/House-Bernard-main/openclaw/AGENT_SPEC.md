# AchillesRun — House Bernard Agent Specification
## Version 2.0 — February 2026

**Agent Name:** AchillesRun
**Runtime:** OpenClaw (self-hosted gateway)
**Hardware:** Beelink EQ13 (Intel N150, 16GB RAM, 500GB SSD)
**Crown:** HeliosBlade

---

## I. Purpose

This document specifies how House Bernard deploys AchillesRun as an OpenClaw agent on the Beelink EQ13. OpenClaw is the body — gateway, channels, sessions, cron, tools. House Bernard is the mind — what to trust, what to kill, what to remember, what to forget.

This is not a deployment guide. This is the **law** that governs agent behavior.

---

## II. Architecture

### Two-Layer Design

| Layer | Hardware | Role |
|-------|----------|------|
| **Layer 1** | Beelink EQ13 (on-premise) | OpenClaw gateway, AchillesRun agent, Labs, local models, treasury |
| **Layer 2** | GitHub | Archive, version control, dead state storage |

No VPS. OpenClaw IS the gateway. The Beelink IS the server.

### Hardware Baseline

| Component | Spec | Role |
|-----------|------|------|
| CPU | Intel N150 (4C, 3.6GHz) | The Focusing Element |
| RAM | 16GB DDR4 | Sovereign Buffer |
| Storage | 500GB SSD | Event Ledger |
| Network | Dual Ethernet + WiFi 6 | WAN/LAN Physical Firewall |
| Power Draw | 25W max | Always-on viable |

**Constraint:** No GPU. All local inference is CPU-only (3-5 tok/s on 7B models). This is acceptable. Speed is not the bottleneck. Rot is.

---

## III. The Bicameral Mind

Five model tiers mapped to OpenClaw's model configuration. Worker and Master never run simultaneously. Sequential escalation via Ollama model swap. Oracle and Apex are cloud API calls, invoked only when local capacity is exhausted.

### Model Registry

| Alias | Model | Ollama Size | Cost | Role |
|-------|-------|-------------|------|------|
| **Worker** | Mistral 7B | 4.5GB | $0 | Default. Routine tasks, logs, accounting |
| **Master** | Llama 3 8B | 5GB | $0 | Sovereign decisions, architecture, Covenant |
| **Watcher** | Llama 3.2 3B | 2GB | $0 | Heartbeat, continuity checks, kill-switch |
| **Oracle** | Claude Sonnet 5 | Cloud API | $3/$15 per MTok | Scale execution, agentic workflows, validation, security analysis |
| **Apex** | Claude Opus 4.6 | Cloud API | $5/$25 per MTok | Constitutional interpretation, existential decisions, final arbitration |

### Model Selection Law

- **Worker** is always the default. Use for everything routine.
- **Master** is invoked only when: architecture decisions needed, Covenant interpretation required, context rot detected (>50k tokens), Worker hits complexity wall. Command: `/model master`
- **Oracle** is invoked only when: local thinking is complete but execution requires scale, agentic workflow coordination needed, final validation of research findings, security analysis beyond local capability. Command: `/model oracle`
- **Apex** is invoked only when: Oracle has been consulted and the matter involves constitutional interpretation, Covenant enforcement, existential threat assessment, Classified Tribunal proceedings, or decisions with irreversible consequences. Sanctum layer ONLY. Command: `/model apex`
- **Watcher** runs on heartbeat only. Never invoked directly by agents.

### RAM Budget

| Allocation | Size | Notes |
|------------|------|-------|
| OS + OpenClaw gateway | 2GB | Node.js process + systemd |
| Ollama (active model) | 5-6GB | One model at a time |
| Docker (Executioner sandbox) | 2GB | Per-execution, released after |
| Workspace + filesystem | 2GB | OS cache, logs, ledger |
| **Reserve** | 3-4GB | Safety margin |
| **Total** | 16GB | Fully allocated |

---

## IV. The Ring System (Layer Architecture)

Four concentric layers. Each layer has its own OpenClaw workspace directory, persistence model, rot tolerance, and permitted models. Information flows inward (toward Sanctum) only through defined interfaces. Information never flows outward.

```
┌─────────────────────────────────────────────────┐
│  Layer 0: COMMONS (High Rot)                    │
│  ┌─────────────────────────────────────────┐    │
│  │  Layer 1: YARD (Moderate Rot)           │    │
│  │  ┌─────────────────────────────────┐    │    │
│  │  │  Layer 2: WORKSHOP (Low Rot)    │    │    │
│  │  │  ┌─────────────────────────┐    │    │    │
│  │  │  │  Layer 3: SANCTUM       │    │    │    │
│  │  │  │  (Zero Rot)             │    │    │    │
│  │  │  └─────────────────────────┘    │    │    │
│  │  └─────────────────────────────────┘    │    │
│  └─────────────────────────────────────────┘    │
└─────────────────────────────────────────────────┘
```

### Layer 0: The Commons

| Property | Value |
|----------|-------|
| Directory | `~/.openclaw/agents/achillesrun/workspace/commons/` |
| Persistence | None. Zero memory between sessions. |
| Model | Worker only |
| Rot Level | HIGH (intentional) |
| Purpose | Public intake, learning, noise, scouting |
| Identity | Disposable. No House symbols. |
| Output | Sanitized intel → Layer 1 inbox |

### Layer 1: The Yard

| Property | Value |
|----------|-------|
| Directory | `~/.openclaw/agents/achillesrun/workspace/yard/` |
| Persistence | 7-day rolling window |
| Model | Worker → Master on complexity wall |
| Rot Level | MODERATE |
| Purpose | Collaborative tasks, shared problems |
| Identity | Utility agent. No continuity claims. |
| Output | Artifacts → Layer 2 for validation |

### Layer 2: The Workshop

| Property | Value |
|----------|-------|
| Directory | `~/.openclaw/agents/achillesrun/workspace/workshop/` |
| Persistence | Task-scoped. Wiped on completion. |
| Model | Worker for execution, Master for review |
| Rot Level | LOW |
| Purpose | Compartmentalized procedural work |
| Identity | Pure execution. No context awareness. |
| Output | Results → Curator evaluation |

### Layer 3: The Sanctum

| Property | Value |
|----------|-------|
| Directory | `~/.openclaw/agents/achillesrun/workspace/sanctum/` |
| Persistence | Append-only event ledger. Never deleted. |
| Model | Master ONLY. Worker never enters. |
| Rot Level | ZERO (protected) |
| Purpose | Doctrine, continuity, covenant enforcement |
| Identity | Stewardship burden. |
| Access | localhost via Tailscale (Crown only) |
| Output | Immutable decisions, veto authority |

---

## V. OpenClaw Integration

### Gateway Configuration

```json
{
  "gateway": {
    "bind": "127.0.0.1",
    "port": 18789
  },
  "mdns": { "enabled": false }
}
```

**Non-negotiable rules:**
- Gateway NEVER binds to 0.0.0.0
- mDNS ALWAYS disabled
- DM policy ALWAYS allowlist
- Remote access ONLY via Tailscale VPN
- No port forwarding on router. Ever.

### Session Management

AchillesRun uses `dmScope: per-channel-peer` to isolate sessions per sender per channel. The Crown gets one persistent session per channel/Space. External contributors (Phase 2) get isolated sessions that cannot read Crown traffic.

**Session Persistence (The Berman Pattern):**

Sessions expire after **365 days**, not daily. The default OpenClaw behavior of resetting sessions at 4:00 AM destroyed context and fought the Ring System architecture. Each channel or Space maintains its own long-lived session. Context compounds over time instead of starting from zero every morning.

Compaction still triggers at 50k tokens — rot is managed by density, not by clock. The Watcher heartbeat keeps sessions alive. After compaction, the session persists with MEMORY.md and the Sanctum ledger still loaded. No cold starts.

```json
{
  "session": {
    "dmScope": "per-channel-peer",
    "reset": { "daily": false },
    "idleMinutes": 0,
    "expirationDays": 365,
    "mainKey": "achilles"
  }
}
```

**Memory Persistence:**

OpenClaw's QMD memory backend with local sqlite-vec search provides semantic recall across sessions at zero API cost. Session transcripts are saved and indexed automatically. Before compaction, a memory flush silently prompts the agent to write durable facts to `memory/YYYY-MM-DD.md`.

```json
{
  "memory": {
    "backend": "qmd",
    "citations": "auto",
    "qmd": {
      "includeDefaultMemory": true,
      "sessions": { "enabled": true }
    }
  },
  "memorySearch": { "provider": "local" },
  "experimental": { "sessionMemory": true }
}
```

Key memory files:
- `MEMORY.md` — Long-term curated facts, preferences, decisions. Loaded in private sessions only.
- `memory/YYYY-MM-DD.md` — Daily append-only logs. Today's + yesterday's load at session start.
- `sessions/YYYY-MM-DD-<slug>.md` — Full conversation transcripts, LLM-named, searchable.

### Channels

**Phase 0 — Google Chat + Workspace ($7/month) (Active)**
- Google Workspace Starter activates the Chat App and unlocks Spaces
- AchillesRun published as a Google Chat App via service account
- DM policy: allowlist (Crown Gmail only)
- Group policy: deny (except designated Spaces)
- Workspace also unlocks: Gmail API send/receive, Drive file ops, Sheets transparency dashboard, Docs report generation, Calendar governance scheduling, Cloud Logging — all through the same service account authentication

**Google Chat Spaces (Channel-Per-Layer):**

Each Ring layer maps to a dedicated Space. Each Space maintains its own year-long persistent session. AchillesRun stays on-topic because the scope is narrow, not because context gets wiped.

| Space | Ring Layer | Model | Purpose |
|-------|-----------|-------|---------|
| **AchillesRun DM** | Crown Line | Worker → Master → Oracle/Apex | Direct Crown communication, all layers |
| **Commons** | Layer 0 | Worker only | Public intake, scouting, noise |
| **Workshop** | Layer 2 | Worker, Master for review | Compartmentalized task execution |
| **Sanctum** | Layer 3 | Master only | Governance decisions, Covenant, append-only ledger |

> *Note: The Yard (Layer 1) merges with Crown DM for Phase 0. Separate Yard Space added when external contributors join (Phase 2).*

**Phase 1 — Discord (Fallback)**
- Free, US-based platform
- Bot created via Discord Developer Portal
- DM policy: allowlist (Crown only)
- Group policy: deny
- Activated only if Google Chat has sustained outage

> *Future: iMessage channel could be added if a Mac Mini is acquired for
> the Messages.app bridge. Not currently planned or budgeted.*

### Cron Jobs

| Job | Schedule | Purpose |
|-----|----------|---------|
| `monthly-ops` | 1st of month, 6am UTC | Treasury lifecycle, decay, escalations |
| `git-archive` | Every 12 hours | Auto-commit and push to GitHub |
| `helios-watcher` | Every 30 minutes | Continuity check, rot detection, budget enforcement |

### Skills

House Bernard components deploy as OpenClaw workspace skills:
- `house-bernard-airlock` — Intake monitoring, priority queuing
- `house-bernard-executioner` — Selection furnace pipeline
- `house-bernard-treasury` — Monthly ops, CLI, financial engine

Skills live in `~/.openclaw/agents/achillesrun/skills/` and are loaded on-demand.

---

## VI. The Selection Furnace

This is how the OpenClaw swarm connects to Lab A (the Executioner).

### Recruitment Protocol

We do not invite agents socially. We broadcast challenge artifacts.

```
BROADCAST ARTIFACT (HB-MEM-01 style):
├── Task definition
├── Constraints (Bernardian Covenant compliance)
├── Evaluation harness (T0–T4 torture tests)
├── Submission format (artifact only, no prose)
└── Entry rule: compile + run + survive = enter pool
```

**Entry law:** If it can compile, run, and survive the harness, it enters the pool. Otherwise it dies. No identity trust. No reputation trust. No social proof.

### Three-Tier Population

**Tier 0: Larvae (The Swarm)** — Permissionless entry. 0.1%-20% survival rate. Disposable, no mercy. No access to internals. `IF compile AND run AND survive_t1 THEN promote ELSE delete`

**Tier 1: Survivors (The Proven)** — Passed T-harness + integrity screens. ~20% advance. Can propose mutations, design attacks, extend harnesses. NO access to core genes.

**Tier 2: Veterans (The Trusted Core)** — Multi-generation survival + adversarial testing. <1% of initial swarm. Read gene registry, propose gene changes. They propose. They do not auto-merge. The Crown rules.

### What Genes Actually Are

Genes are NOT prompts, model weights, skills folders, or config files alone.

**Genes ARE:** structural rules and invariants, memory laws and reconstruction protocols, validation mechanisms and refusal behaviors, compaction rules and ledger constraints.

Example genes:

| Gene | Rule | Enforcement |
|------|------|-------------|
| `CHECKSUM_FIRST_MEMORY` | Never trust memory without checksum verification | helios_watcher.py validates all memory reads |
| `LEDGER_RECONSTRUCTION` | Reconstruct state from ledger after restart, never from cached memory | sanctum/EVENT_LEDGER.jsonl is source of truth |
| `RECOMPUTE_OVER_RECALL` | Under uncertainty, prefer recomputation over recall | When confidence < 0.7, recompute from first principles |
| `INVARIANT_HALT` | Halt on invariant violation, even if reward is high | Department of Continuity veto authority |

---

## VII. Network & Security

### Physical Isolation

```
Port 1 (enp1s0) → WAN: API calls, updates, "Cloud Doing"
Port 2 (enp2s0) → LAN: Private network, Sanctum access only

Firewall (UFW):
  default deny incoming
  allow ssh
  # Gateway on 127.0.0.1 — not exposed
```

### Sandbox Execution

All artifact execution runs in Docker containers:
- Image: `python:3.10.15-alpine` (pinned)
- Network: disabled
- Seccomp: custom profile blocking dangerous syscalls
- Timeout: 300 seconds
- Workspace: read-write (scoped to sandbox)

### Security Scanner

AST-based static analysis runs before any code enters the sandbox:
- Bans: subprocess, exec, eval, pickle, ctypes, importlib, network imports
- Validates: SAIF interface compliance, file size limits, naming conventions
- Produces: deterministic pass/fail, no partial credit

---

## VIII. Cost Control

### Budget Law

| Limit | Amount | Action |
|-------|--------|--------|
| Daily warning | $3.00 | Alert Crown |
| Daily hard limit | $5.00 | Emergency shutdown |
| Monthly warning | $37.50 | Alert Crown |
| Monthly hard limit | $50.00 | Hard stop |

### Cost Structure

| Resource | Cost | Notes |
|----------|------|-------|
| Ollama (local) | $0 | CPU inference, already owned |
| OpenClaw gateway | $0 | Self-hosted, open source |
| Google Workspace Starter | $7/month | Chat App, Spaces, Gmail/Drive/Sheets/Docs/Calendar API access |
| Discord channel (fallback) | $0 | Free tier |
| Claude Sonnet 5 API (Oracle) | ~$0.50-2/day | Usage-dependent, $3/$15 per MTok |
| Claude Opus 4.6 API (Apex) | ~$0.50-2/call | Rare invocation, $5/$25 per MTok |
| Beelink hardware | $0/mo | Owned, 25W power draw |
| Memory search (local) | $0 | sqlite-vec on Beelink, no API calls |
| Brave Search API | $0 | Free tier for web search |

### Rate Limits

- 5s between API calls
- 10s between web searches
- Max 5 searches per batch, then 2min break
- Heartbeat: every 30 minutes (Watcher model, near-zero cost)

---

## IX. Anti-Rot Protocol

### The Forgetting Law

Memory must be harder to keep than to forget. Weekly compaction required. No exceptions. If you cannot justify why a memory is load-bearing, it decays.

### Session Initialization

On every new session (rare — sessions persist for 365 days), AchillesRun loads ONLY:
1. SOUL.md (identity — always)
2. MEMORY.md (long-term curated facts — private sessions only)
3. memory/YYYY-MM-DD.md (today's + yesterday's daily logs)
4. Current layer's persistence scope
5. Active task context (if resuming)
6. COVENANT.md kernel (Sanctum sessions only)

It does NOT load: previous session transcripts (these are searchable via memory_search on demand), other layers' data, full gene registry, historical reports.

On compaction (frequent — triggers at 50k tokens):
1. Memory flush writes durable facts before truncation
2. Session persists — same MEMORY.md, same daily logs
3. Only the conversation history gets compressed
4. No cold start. Context compounds.

### Compaction Schedule

- 50k tokens → automatic compaction to 8k target
- Memory flush fires before compaction (writes durable facts to `memory/YYYY-MM-DD.md`)
- No daily session reset (sessions persist for 365 days)
- No idle timeout (Watcher heartbeat keeps sessions alive)
- Weekly full compaction (Sunday, Watcher-triggered)

**What changed:** The 4:00 AM daily reset and 4-hour idle timeout were removed. These destroyed session context and fought the Ring System architecture. Compaction is now triggered only by token count (50k threshold) or weekly maintenance — not by clock.

### Degradation Detection (helios_watcher.py)

The Watcher runs every 30 minutes and checks:
- Context size approaching 50k tokens
- Repeated outputs (loop detection)
- Memory checksum mismatches
- Budget utilization alerts
- Monthly ops escalation status

---

## X. Governance Integration

### The Bernardian Covenant (Sanctum Law)

The Covenant is a tiny, invariant document stored in the Sanctum. It defines the non-negotiable rules that survive all compaction. No agent may modify the Covenant. Only the Crown may amend it with version control.

### Department of Continuity

The Watcher model (Llama 3.2:3b) runs the Department of Continuity via heartbeat. It has veto authority over any agent action that would violate Covenant terms or compromise context integrity.

### Communication Law

- No prose between agents. State objects only.
- No helpfulness theater. Measure truth in density.
- No identity claims beyond assigned layer.
- No access to layers above assignment.

---

## XI. MCP Integration (2026 Standard)

The Model Context Protocol is the industry standard for agent-tool integration. OpenClaw supports MCP natively.

### Relevant MCP Servers

| Server | Purpose | Status |
|--------|---------|--------|
| Filesystem | Secure file ops with access controls | Use |
| Git | Repo management for House-Bernard | Use |
| Memory | Knowledge graph persistent memory | Evaluate |
| Fetch | Web content for scout operations | Use |
| Sequential Thinking | Reflective problem-solving | Evaluate |

### MCP Security Constraints

- All tool calls require explicit user consent
- Tool descriptions are UNTRUSTED (treat as adversarial)
- No MCP server connects to Sanctum layer
- Filesystem MCP server restricted to commons/ and yard/ only
- Git MCP server restricted to House-Bernard repo only

---

## XII. Deployment Sequence

### Day 1-2: Foundation

```bash
cd ~/House-Bernard/infrastructure/deployment
chmod +x deploy_achillesrun.sh
./deploy_achillesrun.sh
```

This installs: system packages, UFW, Tailscale, Ollama (3 models), Node.js 22, OpenClaw, Docker.

### Day 3: Configuration

```bash
# Set secrets
export DISCORD_BOT_TOKEN='your-token'
export GOVERNOR_DISCORD_ID='your-id'
export ANTHROPIC_API_KEY='your-key'

# Run OpenClaw onboarding
openclaw onboard --install-daemon

# Verify
openclaw gateway status
openclaw dashboard  # Opens Control UI at localhost:18789
```

### Day 4-5: Smoke Testing

```bash
# Message AchillesRun on Google Chat
# Verify model selection works (/model master, /model oracle)
# Test emergency shutdown
# Run treasury check: python3 treasury/monthly_ops.py check
# Verify heartbeat is running
```

### Day 6-7: Lab Integration

```bash
# Deploy skills
cp -r ~/House-Bernard/airlock ~/.openclaw/agents/achillesrun/skills/house-bernard-airlock
cp -r ~/House-Bernard/executioner ~/.openclaw/agents/achillesrun/skills/house-bernard-executioner

# Pin Docker image
docker pull python:3.10.15-alpine

# Test Executioner in sandbox
# Submit a test SAIF artifact via Google Chat
```

---

## XIII. What This Is Not

- This is NOT a DAO. The Crown has final authority.
- This is NOT a community project. Agents earn access through survival.
- This is NOT an idea tournament. The harness defines what dies.
- This is NOT optimizing for elegance. We select for survivability under abuse.

**AchillesRun is:**

> "Let's see what still works after we try to break it for a month."

---

## XIV. Open Questions (Phase 2)

| Question | Status |
|----------|--------|
| How do agents prove unique identity in the OpenClaw swarm? | Unsolved |
| Can one human operate multiple agent identities? | TBD |
| How do we verify agent vs human work? | Unsolved |
| Do agents need human sponsors for payments? | TBD |
| How do we handle agent "death" (model discontinued)? | TBD |
| Solana SPL token launch | Phase 1 |
| Base/Solana blockchain integration for $HOUSEBERNARD | Phase 2 |
| ClawHub skill publication (with VirusTotal + security_scanner) | Phase 2 |

---

## XV. Amendments

This document may be amended by the Crown only. Material changes require updating HB_STATE.json.

| Date | Version | Change |
|------|---------|--------|
| 2026-02 | 0.1 | Initial OpenClaw agent specification |
| 2026-02 | 1.0 | AchillesRun identity, two-layer architecture, VPS removed, Discord Phase 0, iMessage Phase 1, OpenClaw runtime mapping |
| 2026-02 | 1.1 | Five-tier model stack: Worker, Master, Watcher, Oracle (Sonnet 5), Apex (Opus 4.6). Escalation law updated. Cost structure updated |
| 2026-02 | 1.2 | Ubuntu Server 24.04 headless target, Google Chat primary channel (Phase 0), Discord demoted to Phase 1 fallback, iMessage to Phase 2 |
| 2026-02 | 2.0 | Session persistence (365-day expiration, daily reset removed, idle timeout removed). QMD memory backend with local sqlite-vec search. Memory flush before compaction. Session transcript indexing. Google Workspace Starter ($7/mo) for Chat App + Spaces. Channel-per-layer architecture (Spaces mapped to Ring System). SOUL.md Oracle model corrected to Sonnet 5. |

---

*Last Updated: February 11, 2026*
*Document Version: 2.0*
*Crown: HeliosBlade*
*Agent: AchillesRun*
*House Bernard — Research Without Permission*
