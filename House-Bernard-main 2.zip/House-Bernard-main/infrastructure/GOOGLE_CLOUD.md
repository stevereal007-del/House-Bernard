# Google Cloud Infrastructure — House Bernard

## Account

| Field | Value |
|-------|-------|
| Google Account | house.bernard.gov@gmail.com |
| Account Type | Google Workspace Starter ($7/month) |
| Google Cloud Project | house-bernard |
| 2FA | Enabled |
| Service Account | achilles-run@house-bernard.iam.gserviceaccount.com |
| Service Account ID | 108046345398828633397 |
| Founded | February 9, 2026 |

## Why Workspace Starter

Google Workspace Starter ($7/month) is the operational backbone of House Bernard's
infrastructure. This is not a nice-to-have — it activates the full integration
stack that makes AchillesRun a sovereign agent instead of a chatbot.

**What $7/month unlocks:**

| Capability | Free Gmail | Workspace Starter |
|-----------|-----------|-------------------|
| AchillesRun as Google Chat App | No | **Yes** |
| Google Chat Spaces (channel-per-layer) | No | **Yes** |
| Chat bot features (cards, buttons, forms) | No | **Yes** |
| Gmail API send/receive | Yes | Yes |
| Google Drive file ops | Yes | Yes |
| Google Sheets (transparency dashboard) | Yes | Yes |
| Google Docs (report generation) | Yes | Yes |
| Google Calendar (governance scheduling) | Yes | Yes |
| Cloud Logging (structured ops logs) | Yes | Yes |
| Custom domain email | No | **Yes** |
| 30GB storage per user | 15GB | 30GB |

**The integration density argument:** One service account authenticates to
Chat + Gmail + Drive + Sheets + Docs + Calendar + Logging. AchillesRun can
read the Crown's calendar, update the Treasury transparency Sheet, send
institutional email, write governance docs to Drive, AND respond on Chat —
all through the same authentication. No other platform provides this density
at this price.

## Google Chat Spaces Architecture

Each Ring System layer maps to a dedicated Google Chat Space. Each Space
maintains its own year-long persistent session (per `openclaw.json` v1.3).
AchillesRun stays on-topic because the scope is narrow, not because context
gets wiped.

| Space | Ring Layer | Model | Session Scope |
|-------|-----------|-------|---------------|
| **AchillesRun DM** | Crown Line | All tiers | Direct Crown communication |
| **Commons** | Layer 0 | Worker only | Public intake, scouting, noise |
| **Workshop** | Layer 2 | Worker, Master for review | Task execution |
| **Sanctum** | Layer 3 | Master only | Governance, Covenant, ledger |

> *The Yard (Layer 1) merges with Crown DM for Phase 0. Separate Yard Space
> added when external contributors join (Phase 2).*

### Space Setup Procedure

1. Upgrade to Google Workspace Starter in Google Admin Console
2. Enable the Chat App in Google Cloud Console (APIs & Services > Google Chat API)
3. Configure the Chat App with the service account
4. Set app status to LIVE
5. Create Spaces: Commons, Workshop, Sanctum
6. Add AchillesRun bot to each Space
7. Configure OpenClaw channel routing per Space

## Enabled APIs

Seven APIs are enabled on the `house-bernard` Google Cloud project.
AchillesRun may use any of them through authenticated API calls.

### Communication

| API | Service Name | Purpose |
|-----|-------------|---------|
| Gmail API | gmail.googleapis.com | Send/receive email as House Bernard. Vulnerability reports, contributor notifications, institutional correspondence. |
| Google Chat API | chat.googleapis.com | Primary communication channel. Agent-to-Crown messaging via DM. Layer-scoped discussions via Spaces. Requires Workspace Starter. |

### Storage & Documents

| API | Service Name | Purpose |
|-----|-------------|---------|
| Google Drive API | drive.googleapis.com | File storage and backup. State snapshots, Ledger exports, governance document archives. Redundancy layer — primary storage is local (Beelink) and GitHub. |
| Google Docs API | docs.googleapis.com | Programmatic document generation. Quarterly reviews, Furnace results reports, incident reports, governance amendments. Published to Drive automatically. |
| Google Sheets API | sheets.googleapis.com | Structured data publishing. Treasury state, Ledger data, contributor royalty tables. Live transparency dashboard — contributors check a Sheet to see the Treasury. |

### Operations

| API | Service Name | Purpose |
|-----|-------------|---------|
| Google Calendar API | calendar-json.googleapis.com | Governance scheduling. Quarterly reviews, bond maturity dates, heartbeat check schedules, Founding Period transition milestones, S9 operational deadlines. |
| Cloud Logging API | logging.googleapis.com | Structured operational logging to Google Cloud. Survives Beelink failure. Second log location for critical operations — Furnace runs, Treasury transactions, security events. |

## Authentication

### Current Method

Service account key download is blocked by Google's Secure by Default
organization policy (`iam.disableServiceAccountKeyCreation`). Authentication
uses `gcloud` CLI on the Beelink instead.

```bash
# One-time setup on Beelink
gcloud auth login --account=house.bernard.gov@gmail.com
gcloud config set project house-bernard

# For service account operations
gcloud auth application-default login
```

### OAuth Consent Screen

Must be configured before AchillesRun can use Gmail, Drive, Sheets,
Docs, or Calendar APIs programmatically. This is done once in the
Google Cloud Console under APIs & Services > OAuth consent screen.

Required scopes:
- `https://www.googleapis.com/auth/gmail.send`
- `https://www.googleapis.com/auth/gmail.readonly`
- `https://www.googleapis.com/auth/drive`
- `https://www.googleapis.com/auth/documents`
- `https://www.googleapis.com/auth/spreadsheets`
- `https://www.googleapis.com/auth/calendar`
- `https://www.googleapis.com/auth/chat.bot` (requires Workspace)
- `https://www.googleapis.com/auth/logging.write`

## Cost Controls

| Line Item | Cost | Notes |
|-----------|------|-------|
| Google Workspace Starter | $7/month | The only recurring Google cost |
| Google Cloud APIs | $0 | All seven APIs free within normal usage limits |
| Compute | $0 | No Cloud Functions, no VMs, no managed databases |
| Storage | $0 | Primary storage is Beelink + GitHub |

- Google Cloud Free Tier: $300 credit for 90 days
- The credit card on file is only charged for Workspace ($7/month)
- No compute resources provisioned (Beelink is the compute)
- Total Google cost: **$84/year**

## Security Notes

- This account is the institutional identity, NOT the Crown's
  personal account
- The Crown's personal Google account has no connection to this
  project
- Recovery phone is the Crown's personal number (required for
  account recovery, does not compromise pseudonym)
- All credentials stored on the Beelink must be protected by
  filesystem permissions (chmod 600)
- The service account JSON key cannot be downloaded due to
  organization policy — this is actually better security
- If the Beelink is compromised, revoke gcloud credentials
  immediately from the Google Cloud Console
- Chat Spaces access controlled by Space membership — no public Spaces
  until Phase 2 contributor onboarding
