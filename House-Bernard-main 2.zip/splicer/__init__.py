# House Bernard Gene Splicer
