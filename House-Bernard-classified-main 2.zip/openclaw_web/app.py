"""
House Bernard — OpenClaw Platform
FastAPI + HTMX + SQLite. The front door to everything.
"""
from __future__ import annotations

import hashlib
import os
import shutil
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Request, Form, UploadFile, File, Cookie, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from openclaw_web import config
from openclaw_web import database as db
from openclaw_web.auth import authenticate, register
from openclaw_web.agents.achillesrun import AchillesRun
from openclaw_web.agents.sub_agents import Warden, Treasurer, Magistrate

# ── App setup ──

app = FastAPI(title="House Bernard — OpenClaw", version="1.0.0")
app.mount("/static", StaticFiles(directory=str(config.STATIC_DIR)), name="static")
templates = Jinja2Templates(directory=str(config.TEMPLATES_DIR))

# ── Database and agents ──

conn = db.init_db(config.DB_PATH)
achilles = AchillesRun(conn)
warden = Warden(conn)
treasurer = Treasurer(conn)
magistrate = Magistrate(conn)


@app.on_event("startup")
async def startup():
    achilles.start()
    warden.start()
    treasurer.start()
    magistrate.start()


@app.on_event("shutdown")
async def shutdown():
    achilles.stop()
    warden.stop()
    treasurer.stop()
    magistrate.stop()
    conn.close()


# ── Helpers ──

def _get_citizen(request: Request, token: str = None) -> Optional[dict]:
    """Get authenticated citizen from cookie or param."""
    t = token or request.cookies.get("hb_token", "")
    return authenticate(conn, t)


def _ctx(request: Request, citizen: dict = None, **kwargs) -> dict:
    """Build template context."""
    return {"request": request, "citizen": citizen, **kwargs}


# ── Routes: Dashboard ──

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    citizen = _get_citizen(request)
    recent_subs = db.list_submissions(conn)[:10]
    open_briefs = db.list_briefs(conn, "open")[:5]
    agents = db.get_agent_status(conn)
    activity = achilles.bus.recent_activity(10)
    return templates.TemplateResponse("dashboard.html", _ctx(
        request, citizen,
        submissions=recent_subs, briefs=open_briefs,
        agents=agents, activity=activity,
    ))


# ── Routes: Auth ──

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", _ctx(request))


@app.post("/login")
async def login(request: Request, alias: str = Form(...), token: str = Form("")):
    citizen = db.get_citizen_by_alias(conn, alias)
    if citizen and citizen.get("auth_token") == token:
        response = RedirectResponse("/", status_code=303)
        response.set_cookie("hb_token", token, httponly=True, max_age=86400 * 30)
        return response
    return templates.TemplateResponse("login.html", _ctx(
        request, error="Invalid alias or token"
    ))


@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return templates.TemplateResponse("register.html", _ctx(request))


@app.post("/register")
async def register_citizen(request: Request, alias: str = Form(...),
                            wallet: str = Form("")):
    result = register(conn, alias, wallet)
    if "error" in result:
        return templates.TemplateResponse("register.html", _ctx(
            request, error=result["error"]
        ))
    response = RedirectResponse("/", status_code=303)
    response.set_cookie("hb_token", result["auth_token"], httponly=True, max_age=86400 * 30)
    return response


@app.get("/logout")
async def logout():
    response = RedirectResponse("/", status_code=303)
    response.delete_cookie("hb_token")
    return response


# ── Routes: Forum ──

@app.get("/forum", response_class=HTMLResponse)
async def forum_index(request: Request):
    citizen = _get_citizen(request)
    topics = db.list_topics(conn)
    return templates.TemplateResponse("forum.html", _ctx(
        request, citizen, topics=topics
    ))


@app.get("/forum/{topic_id}", response_class=HTMLResponse)
async def forum_topic(request: Request, topic_id: int):
    citizen = _get_citizen(request)
    topic = db.get_topic(conn, topic_id)
    if not topic:
        raise HTTPException(404)
    threads = db.list_threads(conn, topic_id)
    return templates.TemplateResponse("topic.html", _ctx(
        request, citizen, topic=topic, threads=threads
    ))


@app.get("/forum/{topic_id}/new", response_class=HTMLResponse)
async def new_thread_form(request: Request, topic_id: int):
    citizen = _get_citizen(request)
    if not citizen:
        return RedirectResponse("/login", status_code=303)
    topic = db.get_topic(conn, topic_id)
    return templates.TemplateResponse("new_thread.html", _ctx(
        request, citizen, topic=topic
    ))


@app.post("/forum/{topic_id}/new")
async def create_thread(request: Request, topic_id: int,
                        title: str = Form(...), body: str = Form(...)):
    citizen = _get_citizen(request)
    if not citizen:
        return RedirectResponse("/login", status_code=303)
    thread_id = db.create_thread(conn, topic_id, title, body, citizen["id"])
    return RedirectResponse(f"/forum/{topic_id}/{thread_id}", status_code=303)


@app.get("/forum/{topic_id}/{thread_id}", response_class=HTMLResponse)
async def forum_thread(request: Request, topic_id: int, thread_id: int):
    citizen = _get_citizen(request)
    thread = db.get_thread(conn, thread_id)
    if not thread:
        raise HTTPException(404)
    posts = db.list_posts(conn, thread_id)
    topic = db.get_topic(conn, topic_id)
    return templates.TemplateResponse("thread.html", _ctx(
        request, citizen, thread=thread, posts=posts, topic=topic
    ))


@app.post("/forum/{topic_id}/{thread_id}/reply")
async def reply_to_thread(request: Request, topic_id: int, thread_id: int,
                          body: str = Form(...)):
    citizen = _get_citizen(request)
    if not citizen:
        return RedirectResponse("/login", status_code=303)
    thread = db.get_thread(conn, thread_id)
    if not thread or thread.get("locked"):
        raise HTTPException(403)
    db.create_post(conn, thread_id, citizen["id"], body)
    return RedirectResponse(f"/forum/{topic_id}/{thread_id}", status_code=303)


# ── Routes: Briefs ──

@app.get("/briefs", response_class=HTMLResponse)
async def briefs_list(request: Request):
    citizen = _get_citizen(request)
    open_briefs = db.list_briefs(conn, "open")
    claimed_briefs = db.list_briefs(conn, "claimed")
    return templates.TemplateResponse("briefs.html", _ctx(
        request, citizen, open_briefs=open_briefs, claimed_briefs=claimed_briefs
    ))


@app.get("/briefs/{brief_id}", response_class=HTMLResponse)
async def brief_detail(request: Request, brief_id: str):
    citizen = _get_citizen(request)
    brief = db.get_brief(conn, brief_id)
    if not brief:
        raise HTTPException(404)
    return templates.TemplateResponse("brief_detail.html", _ctx(
        request, citizen, brief=brief
    ))


@app.post("/briefs/{brief_id}/claim")
async def claim_brief(request: Request, brief_id: str):
    citizen = _get_citizen(request)
    if not citizen:
        return RedirectResponse("/login", status_code=303)
    success = db.claim_brief(conn, brief_id, citizen["id"])
    if success:
        achilles.claim_brief(citizen["id"], brief_id)
    return RedirectResponse(f"/briefs/{brief_id}", status_code=303)


# ── Routes: Submit Artifact ──

@app.get("/submit", response_class=HTMLResponse)
async def submit_page(request: Request):
    citizen = _get_citizen(request)
    if not citizen:
        return RedirectResponse("/login", status_code=303)
    return templates.TemplateResponse("submit.html", _ctx(request, citizen))


@app.post("/submit")
async def submit_artifact(request: Request, artifact: UploadFile = File(...),
                          brief_id: str = Form("")):
    citizen = _get_citizen(request)
    if not citizen:
        return RedirectResponse("/login", status_code=303)

    # Save to inbox
    config.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    dest = config.UPLOAD_DIR / artifact.filename
    content = await artifact.read()
    dest.write_bytes(content)

    # Hash it
    artifact_hash = hashlib.sha256(content).hexdigest()

    # Register submission
    sub_id = db.create_submission(conn, citizen["id"], artifact.filename, artifact_hash, brief_id)

    # Notify AchillesRun
    achilles.submit_artifact(citizen["id"], artifact.filename, artifact_hash, brief_id)

    return templates.TemplateResponse("submit_success.html", _ctx(
        request, citizen, submission_id=sub_id, filename=artifact.filename
    ))


# ── Routes: Citizen Dashboard ──

@app.get("/citizen/{citizen_id}", response_class=HTMLResponse)
async def citizen_page(request: Request, citizen_id: str):
    viewer = _get_citizen(request)
    citizen = db.get_citizen(conn, citizen_id)
    if not citizen:
        raise HTTPException(404)
    submissions = db.list_submissions(conn, citizen_id)
    return templates.TemplateResponse("citizen.html", _ctx(
        request, viewer, profile=citizen, submissions=submissions
    ))


@app.get("/me", response_class=HTMLResponse)
async def my_dashboard(request: Request):
    citizen = _get_citizen(request)
    if not citizen:
        return RedirectResponse("/login", status_code=303)
    return RedirectResponse(f"/citizen/{citizen['id']}", status_code=303)


# ── Routes: Pipeline ──

@app.get("/pipeline", response_class=HTMLResponse)
async def pipeline(request: Request):
    citizen = _get_citizen(request)
    submissions = db.list_submissions(conn)
    agents = db.get_agent_status(conn)
    return templates.TemplateResponse("pipeline.html", _ctx(
        request, citizen, submissions=submissions, agents=agents
    ))


# ── Routes: Governance ──

@app.get("/governance", response_class=HTMLResponse)
async def governance(request: Request):
    citizen = _get_citizen(request)
    return templates.TemplateResponse("governance.html", _ctx(request, citizen))


# ── API: Agent status (for HTMX polling) ──

@app.get("/api/agents", response_class=HTMLResponse)
async def api_agents(request: Request):
    agents = db.get_agent_status(conn)
    return templates.TemplateResponse("partials/agent_status.html", _ctx(
        request, agents=agents
    ))


@app.get("/api/activity", response_class=HTMLResponse)
async def api_activity(request: Request):
    activity = achilles.bus.recent_activity(10)
    return templates.TemplateResponse("partials/activity_feed.html", _ctx(
        request, activity=activity
    ))
