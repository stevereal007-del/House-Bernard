"""House Bernard Platform — Test Suite"""
from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path

# Add repo root to path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from openclaw_web import database as db
from openclaw_web.auth import authenticate, register
from openclaw_web.agents.message_bus import MessageBus


def get_test_db():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    migration = Path(__file__).parent / "migrations" / "001_initial.sql"
    conn.executescript(migration.read_text(encoding="utf-8"))
    conn.commit()
    return conn


class Results:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.errors = []
    def ok(self, name): self.passed += 1
    def fail(self, name, msg):
        self.failed += 1
        self.errors.append(f"  FAIL: {name} — {msg}")


def run_tests():
    r = Results()
    conn = get_test_db()

    # Citizens
    try:
        cid = db.create_citizen(conn, "TestUser", "abc123wallet", "spark")
        c = db.get_citizen(conn, cid)
        assert c and c["alias"] == "TestUser" and c["tier"] == "spark"
        r.ok("create + get citizen")
    except Exception as e: r.fail("create + get citizen", e)

    try:
        c = db.get_citizen_by_alias(conn, "TestUser")
        assert c and c["wallet_address"] == "abc123wallet"
        r.ok("get by alias")
    except Exception as e: r.fail("get by alias", e)

    try:
        assert len(db.list_citizens(conn)) >= 5
        r.ok("list citizens")
    except Exception as e: r.fail("list citizens", e)

    # Forum
    try:
        assert len(db.list_topics(conn)) == 6
        r.ok("forum topics seeded")
    except Exception as e: r.fail("forum topics seeded", e)

    try:
        tid = db.create_thread(conn, 2, "Test Thread", "Hello", cid)
        t = db.get_thread(conn, tid)
        assert t["title"] == "Test Thread"
        r.ok("create + get thread")
    except Exception as e: r.fail("create + get thread", e)

    try:
        posts = db.list_posts(conn, tid)
        assert len(posts) == 1 and posts[0]["body"] == "Hello"
        r.ok("initial post")
    except Exception as e: r.fail("initial post", e)

    try:
        db.create_post(conn, tid, cid, "Reply")
        assert len(db.list_posts(conn, tid)) == 2
        r.ok("create reply")
    except Exception as e: r.fail("create reply", e)

    try:
        db.create_post(conn, tid, "SYSTEM-ACHILLES", "Bot msg", is_agent=True)
        posts = db.list_posts(conn, tid)
        assert any(p["is_agent"] for p in posts)
        r.ok("agent post")
    except Exception as e: r.fail("agent post", e)

    # Briefs
    try:
        bid = db.create_brief(conn, "Test Brief", "Description", "lab_a", 2)
        b = db.get_brief(conn, bid)
        assert b["status"] == "open"
        r.ok("create brief")
    except Exception as e: r.fail("create brief", e)

    try:
        assert db.claim_brief(conn, bid, cid)
        assert db.get_brief(conn, bid)["status"] == "claimed"
        r.ok("claim brief")
    except Exception as e: r.fail("claim brief", e)

    try:
        assert not db.claim_brief(conn, bid, cid)
        r.ok("no double-claim")
    except Exception as e: r.fail("no double-claim", e)

    # Submissions
    try:
        sid = db.create_submission(conn, cid, "test.zip", "sha256:abc", bid)
        subs = db.list_submissions(conn, cid)
        assert len(subs) == 1 and subs[0]["filename"] == "test.zip"
        r.ok("create submission")
    except Exception as e: r.fail("create submission", e)

    try:
        db.update_submission(conn, sid, "survived", "T4")
        s = db.list_submissions(conn, cid)[0]
        assert s["status"] == "survived" and s["tier_reached"] == "T4"
        r.ok("update verdict")
    except Exception as e: r.fail("update verdict", e)

    # Auth
    try:
        token = db.get_citizen(conn, cid)["auth_token"]
        assert authenticate(conn, token)["id"] == cid
        r.ok("auth valid token")
    except Exception as e: r.fail("auth valid token", e)

    try:
        assert authenticate(conn, "bad-token") is None
        r.ok("reject bad token")
    except Exception as e: r.fail("reject bad token", e)

    try:
        result = register(conn, "NewCitizen", "w456")
        assert "error" not in result and result["auth_token"]
        r.ok("register")
    except Exception as e: r.fail("register", e)

    try:
        assert "error" in register(conn, "NewCitizen")
        r.ok("reject dupe alias")
    except Exception as e: r.fail("reject dupe alias", e)

    # Message Bus
    bus = MessageBus(conn)

    try:
        mid = bus.send("achillesrun", "warden", "task", {"action": "test"})
        assert mid.startswith("msg-")
        r.ok("send message")
    except Exception as e: r.fail("send message", e)

    try:
        p = bus.get_pending("warden")
        assert len(p) >= 1 and p[0]["payload"]["action"] == "test"
        r.ok("get pending")
    except Exception as e: r.fail("get pending", e)

    try:
        bus.complete(mid)
        assert len(bus.get_pending("warden")) == 0
        r.ok("complete message")
    except Exception as e: r.fail("complete message", e)

    try:
        bus.send_task("a", "t", "compute", {"x": 1})
        bus.send_alert("w", "Alert!", "high")
        bus.send_escalation("m", "Escalation", {"d": 1})
        assert len(bus.recent_activity(5)) >= 3
        r.ok("convenience methods")
    except Exception as e: r.fail("convenience methods", e)

    try:
        bus.heartbeat("warden")
        bus.heartbeat("treasurer")
        assert len(bus.get_all_status()) >= 2
        r.ok("heartbeat + status")
    except Exception as e: r.fail("heartbeat + status", e)

    try:
        bus.send("warden", "treasurer", "task", {"action": "direct_test"})
        p = bus.get_pending("treasurer")
        assert any(m["from_agent"] == "warden" for m in p)
        r.ok("sub-agent direct msg")
    except Exception as e: r.fail("sub-agent direct msg", e)

    # Priority ordering
    try:
        c2 = get_test_db()
        b2 = MessageBus(c2)
        b2.send("a", "x", "task", {"order": 3}, "low")
        b2.send("a", "x", "task", {"order": 1}, "emergency")
        b2.send("a", "x", "task", {"order": 2}, "high")
        p = b2.get_pending("x")
        assert p[0]["payload"]["order"] == 1
        assert p[1]["payload"]["order"] == 2
        assert p[2]["payload"]["order"] == 3
        r.ok("priority ordering")
    except Exception as e: r.fail("priority ordering", e)

    conn.close()

    print()
    print("=" * 50)
    print(f"  PLATFORM TESTS: {r.passed}/{r.passed + r.failed} passed")
    if r.errors:
        print()
        for e in r.errors: print(e)
    print("=" * 50)
    return r.failed == 0


if __name__ == "__main__":
    sys.exit(0 if run_tests() else 1)
