-- House Bernard Platform — Initial Schema
-- Run: sqlite3 hb_platform.db < migrations/001_initial.sql

PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

-- Citizens
CREATE TABLE IF NOT EXISTS citizens (
    id TEXT PRIMARY KEY,
    alias TEXT NOT NULL UNIQUE,
    wallet_address TEXT,
    tier TEXT NOT NULL DEFAULT 'visitor',
    auth_token TEXT,
    joined_at TEXT NOT NULL,
    total_earned REAL DEFAULT 0.0,
    CHECK (tier IN ('visitor','spark','flame','furnace','invariant','crown'))
);

-- Forum topics (public or guild-scoped)
CREATE TABLE IF NOT EXISTS forum_topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    description TEXT DEFAULT '',
    guild_id TEXT,
    sort_order INTEGER DEFAULT 0,
    created_at TEXT NOT NULL
);

-- Forum threads
CREATE TABLE IF NOT EXISTS forum_threads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_id INTEGER NOT NULL REFERENCES forum_topics(id),
    title TEXT NOT NULL,
    author_id TEXT NOT NULL REFERENCES citizens(id),
    created_at TEXT NOT NULL,
    last_post_at TEXT NOT NULL,
    pinned INTEGER DEFAULT 0,
    locked INTEGER DEFAULT 0
);

-- Forum posts
CREATE TABLE IF NOT EXISTS forum_posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    thread_id INTEGER NOT NULL REFERENCES forum_threads(id),
    author_id TEXT NOT NULL REFERENCES citizens(id),
    body TEXT NOT NULL,
    created_at TEXT NOT NULL,
    edited_at TEXT,
    is_agent INTEGER DEFAULT 0
);

-- Research briefs
CREATE TABLE IF NOT EXISTS briefs (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    lab TEXT,
    status TEXT NOT NULL DEFAULT 'open',
    claimed_by TEXT REFERENCES citizens(id),
    reward_tier INTEGER DEFAULT 1,
    created_at TEXT NOT NULL,
    deadline TEXT,
    CHECK (status IN ('open','claimed','testing','closed'))
);

-- Artifact submissions
CREATE TABLE IF NOT EXISTS submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    brief_id TEXT REFERENCES briefs(id),
    citizen_id TEXT NOT NULL REFERENCES citizens(id),
    filename TEXT NOT NULL,
    artifact_hash TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'queued',
    submitted_at TEXT NOT NULL,
    verdict_at TEXT,
    tier_reached TEXT,
    CHECK (status IN ('queued','intake','testing','survived','culled','rejected'))
);

-- Agent message bus
CREATE TABLE IF NOT EXISTS agent_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    msg_uuid TEXT NOT NULL UNIQUE,
    from_agent TEXT NOT NULL,
    to_agent TEXT NOT NULL,
    message_type TEXT NOT NULL,
    payload TEXT NOT NULL,
    priority TEXT NOT NULL DEFAULT 'normal',
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL,
    processed_at TEXT,
    CHECK (message_type IN ('task','response','alert','heartbeat','escalation')),
    CHECK (priority IN ('low','normal','high','emergency')),
    CHECK (status IN ('pending','processing','completed','failed'))
);

-- Agent heartbeats
CREATE TABLE IF NOT EXISTS agent_heartbeats (
    agent_name TEXT PRIMARY KEY,
    last_seen TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'online',
    CHECK (status IN ('online','degraded','offline'))
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_threads_topic ON forum_threads(topic_id, last_post_at DESC);
CREATE INDEX IF NOT EXISTS idx_posts_thread ON forum_posts(thread_id, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_to ON agent_messages(to_agent, status, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_type ON agent_messages(message_type, status);
CREATE INDEX IF NOT EXISTS idx_submissions_citizen ON submissions(citizen_id, submitted_at DESC);
CREATE INDEX IF NOT EXISTS idx_briefs_status ON briefs(status);

-- Seed: system agents as citizens
INSERT OR IGNORE INTO citizens (id, alias, tier, joined_at) VALUES
    ('SYSTEM-ACHILLES', 'AchillesRun', 'crown', '2026-02-14T00:00:00Z'),
    ('SYSTEM-WARDEN', 'Warden', 'invariant', '2026-02-14T00:00:00Z'),
    ('SYSTEM-TREASURER', 'Treasurer', 'invariant', '2026-02-14T00:00:00Z'),
    ('SYSTEM-MAGISTRATE', 'Magistrate', 'invariant', '2026-02-14T00:00:00Z');

-- Seed: default forum topics
INSERT OR IGNORE INTO forum_topics (name, description, created_at) VALUES
    ('Announcements', 'Official House Bernard announcements', '2026-02-14T00:00:00Z'),
    ('General', 'Open discussion for all citizens', '2026-02-14T00:00:00Z'),
    ('Research', 'Research briefs, methodology, results', '2026-02-14T00:00:00Z'),
    ('Guild Hall', 'Guild coordination and recruitment', '2026-02-14T00:00:00Z'),
    ('Feedback', 'Platform bugs, feature requests, improvements', '2026-02-14T00:00:00Z'),
    ('Agent Log', 'Automated posts from AchillesRun and sub-agents', '2026-02-14T00:00:00Z');
