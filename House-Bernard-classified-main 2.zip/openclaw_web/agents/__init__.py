"""House Bernard Agent System."""
