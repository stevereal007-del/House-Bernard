"""
House Bernard — Agent Message Bus
SQLite-backed async message queue for agent-to-agent communication.
Agents poll for messages, process them, and post responses.
AchillesRun monitors all traffic for situational awareness.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from datetime import datetime, timezone
from typing import Callable, Optional

from openclaw_web import database as db


class MessageBus:
    """SQLite-backed message bus for agent communication."""

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self._handlers: dict[str, list[Callable]] = {}
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def send(self, from_agent: str, to_agent: str,
             msg_type: str, payload: dict,
             priority: str = "normal") -> str:
        """Send a message to another agent."""
        return db.send_message(
            self.conn, from_agent, to_agent, msg_type, payload, priority
        )

    def send_task(self, from_agent: str, to_agent: str,
                  action: str, data: dict = None,
                  priority: str = "normal") -> str:
        """Convenience: send a task message."""
        payload = {"action": action}
        if data:
            payload.update(data)
        return self.send(from_agent, to_agent, "task", payload, priority)

    def send_response(self, from_agent: str, to_agent: str,
                      in_reply_to: str, result: dict) -> str:
        """Send a response to a previous message."""
        payload = {"in_reply_to": in_reply_to, "result": result}
        return self.send(from_agent, to_agent, "response", payload)

    def send_alert(self, from_agent: str, message: str,
                   severity: str = "normal") -> str:
        """Broadcast an alert to AchillesRun."""
        return self.send(
            from_agent, "achillesrun", "alert",
            {"message": message, "severity": severity},
            priority="high" if severity in ("high", "emergency") else "normal"
        )

    def send_escalation(self, from_agent: str, reason: str, context: dict = None) -> str:
        """Escalate to Crown via AchillesRun."""
        payload = {"reason": reason, "context": context or {}}
        return self.send(from_agent, "achillesrun", "escalation", payload, "emergency")

    def get_pending(self, agent: str) -> list[dict]:
        """Get pending messages for an agent."""
        return db.get_pending_messages(self.conn, agent)

    def complete(self, msg_uuid: str, status: str = "completed") -> None:
        """Mark a message as processed."""
        db.complete_message(self.conn, msg_uuid, status)

    def heartbeat(self, agent_name: str) -> None:
        """Update agent heartbeat."""
        db.update_heartbeat(self.conn, agent_name)

    def get_all_status(self) -> list[dict]:
        """Get all agent statuses."""
        return db.get_agent_status(self.conn)

    # ── Observer pattern for real-time routing ──

    def on(self, message_type: str, handler: Callable) -> None:
        """Register a handler for a message type."""
        if message_type not in self._handlers:
            self._handlers[message_type] = []
        self._handlers[message_type].append(handler)

    def _notify(self, msg: dict) -> None:
        """Notify registered handlers of a new message."""
        msg_type = msg.get("message_type", "")
        for handler in self._handlers.get(msg_type, []):
            try:
                handler(msg)
            except Exception as e:
                print(f"[BUS] Handler error for {msg_type}: {e}")
        # Also notify wildcard handlers
        for handler in self._handlers.get("*", []):
            try:
                handler(msg)
            except Exception:
                pass

    # ── Recent activity (for dashboard) ──

    def recent_activity(self, limit: int = 20) -> list[dict]:
        """Get recent messages for dashboard display."""
        rows = self.conn.execute(
            "SELECT * FROM agent_messages ORDER BY created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
        results = []
        for r in rows:
            d = dict(r)
            try:
                d["payload"] = json.loads(d["payload"])
            except (json.JSONDecodeError, TypeError):
                pass
            results.append(d)
        return results
