"""
House Bernard — Sub-Agent Base + Warden, Treasurer, Magistrate
Each sub-agent polls the message bus, processes tasks, responds.
Sub-agents can message each other directly without routing through AchillesRun.
"""
from __future__ import annotations

import sqlite3
import threading
import time
from datetime import datetime, timezone

from openclaw_web.agents.message_bus import MessageBus
from openclaw_web.agents.model_router import ModelRouter


class SubAgent:
    """Base class for all House Bernard sub-agents."""

    name: str = "unnamed"

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.bus = MessageBus(conn)
        self.router = ModelRouter()
        self._running = False
        self._thread = None

    def start(self) -> None:
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        self.bus.heartbeat(self.name)
        self._log("Online.")

    def stop(self) -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=10)

    def _run_loop(self) -> None:
        while self._running:
            try:
                messages = self.bus.get_pending(self.name)
                for msg in messages:
                    self.handle(msg)
                    self.bus.complete(msg["msg_uuid"])
                self.bus.heartbeat(self.name)
            except Exception as e:
                self._log(f"Error: {e}", level="error")
            time.sleep(5)

    def handle(self, msg: dict) -> None:
        """Override in subclass."""
        raise NotImplementedError

    def _log(self, message: str, level: str = "info") -> None:
        ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
        print(f"[{ts}] [{self.name.upper()}] {message}")


class Warden(SubAgent):
    """Security sub-agent. Runs airlock, executioner, scanning."""

    name = "warden"

    def handle(self, msg: dict) -> None:
        payload = msg.get("payload", {})
        action = payload.get("action", "")

        if action == "artifact_submitted":
            self._process_submission(payload, msg["msg_uuid"])
        elif action == "security_alert":
            self._handle_security_alert(payload, msg["msg_uuid"])
        elif action == "revoke_access":
            self._revoke_citizen(payload, msg["msg_uuid"])
        else:
            self._log(f"Unknown action: {action}")

    def _process_submission(self, payload: dict, msg_uuid: str) -> None:
        """Intake an artifact submission into the pipeline."""
        citizen = payload.get("citizen_id", "?")
        filename = payload.get("filename", "?")
        artifact_hash = payload.get("artifact_hash", "?")

        self._log(f"Processing submission from {citizen}: {filename}")

        # In production this would:
        # 1. Move file from inbox to sandbox
        # 2. Run security scanner
        # 3. Launch executioner T0-T4
        # 4. Report verdict

        # For now, acknowledge receipt and notify AchillesRun
        self.bus.send_response(
            self.name, "achillesrun", msg_uuid,
            {
                "action": "submission_received",
                "citizen": citizen,
                "filename": filename,
                "status": "intake",
            }
        )

    def _handle_security_alert(self, payload: dict, msg_uuid: str) -> None:
        severity = payload.get("severity", "normal")
        self._log(f"Security alert [{severity}]: {payload.get('message', '')}")

        if severity == "emergency":
            self.bus.send_escalation(
                self.name,
                f"Emergency security alert: {payload.get('message', '')}",
                payload
            )

    def _revoke_citizen(self, payload: dict, msg_uuid: str) -> None:
        citizen = payload.get("citizen_id", "?")
        self._log(f"Revoking access for {citizen}")
        # In production: update citizen tier, revoke tokens, block submissions


class Treasurer(SubAgent):
    """Financial sub-agent. Royalties, bonds, payments."""

    name = "treasurer"

    def handle(self, msg: dict) -> None:
        payload = msg.get("payload", {})
        action = payload.get("action", "")

        if action == "compute_royalty":
            self._compute_royalty(payload, msg["msg_uuid"])
        elif action == "royalty_due":
            self._process_payment(payload, msg["msg_uuid"])
        elif action == "artifact_survived":
            self._register_survivor(payload, msg["msg_uuid"])
        else:
            self._log(f"Unknown action: {action}")

    def _compute_royalty(self, payload: dict, msg_uuid: str) -> None:
        citizen = payload.get("citizen", "?")
        artifact = payload.get("artifact", "?")

        self._log(f"Computing royalty for {citizen} artifact {artifact}")

        # In production: use treasury_engine.py to compute actual amounts
        # For now, report back
        self.bus.send_response(
            self.name, "achillesrun", msg_uuid,
            {
                "action": "royalty_computed",
                "citizen": citizen,
                "amount": 0.0,  # Placeholder
                "status": "pending_payment",
            }
        )

    def _process_payment(self, payload: dict, msg_uuid: str) -> None:
        citizen = payload.get("citizen_id", "?")
        amount = payload.get("amount", 0.0)

        self._log(f"Processing payment: {amount} → {citizen}")

        # In production: use solana_dispatcher.py
        # Check if amount > 1% of supply → escalate
        if amount > 0.01:
            self.bus.send_escalation(
                self.name,
                f"Large payment ({amount}) to {citizen} requires Crown approval",
                payload
            )
            return

        self.bus.send_response(
            self.name, "achillesrun", msg_uuid,
            {"action": "payment_processed", "citizen": citizen, "amount": amount}
        )

    def _register_survivor(self, payload: dict, msg_uuid: str) -> None:
        self._log(f"Registering survivor: {payload}")
        self._compute_royalty(payload, msg_uuid)


class Magistrate(SubAgent):
    """Governance sub-agent. Disputes, appeals, moderation."""

    name = "magistrate"

    def handle(self, msg: dict) -> None:
        payload = msg.get("payload", {})
        action = payload.get("action", "")

        if action == "guild_dispute":
            self._handle_dispute(payload, msg["msg_uuid"])
        elif action == "citizenship_appeal":
            self._handle_appeal(payload, msg["msg_uuid"])
        elif action == "forum_moderation":
            self._moderate_post(payload, msg["msg_uuid"])
        else:
            self._log(f"Unknown action: {action}")

    def _handle_dispute(self, payload: dict, msg_uuid: str) -> None:
        guild = payload.get("guild_id", "?")
        self._log(f"Guild dispute: {guild}")

        # Use model router for complex disputes
        ruling = self.router.route(
            "resolve_guild_dispute",
            f"Guild dispute in {guild}: {payload.get('description', 'No details')}\n"
            f"Relevant constitutional articles and precedents should guide the ruling.",
            system="You are the Magistrate of House Bernard. Rule fairly per the Constitution."
        )

        self.bus.send_response(
            self.name, "achillesrun", msg_uuid,
            {"action": "dispute_ruled", "guild": guild, "ruling": ruling}
        )

    def _handle_appeal(self, payload: dict, msg_uuid: str) -> None:
        citizen = payload.get("citizen_id", "?")
        self._log(f"Citizenship appeal from {citizen}")

        # Constitutional questions always escalate
        if payload.get("constitutional", False):
            self.bus.send_escalation(
                self.name,
                f"Constitutional question in appeal from {citizen}",
                payload
            )
            return

        self.bus.send_response(
            self.name, "achillesrun", msg_uuid,
            {"action": "appeal_reviewed", "citizen": citizen}
        )

    def _moderate_post(self, payload: dict, msg_uuid: str) -> None:
        post_id = payload.get("post_id", "?")
        self._log(f"Moderating post {post_id}")

        content = payload.get("content", "")
        verdict = self.router.route(
            "moderate_forum_post",
            f"Should this forum post be allowed? Content: {content[:500]}",
            system="You are a forum moderator for House Bernard. "
                   "Allow open discussion but remove spam, abuse, and OPSEC violations."
        )

        self.bus.send_response(
            self.name, "achillesrun", msg_uuid,
            {"action": "moderation_complete", "post_id": post_id, "verdict": verdict}
        )
