"""
House Bernard — AchillesRun Core
The Steward. Receives all requests, delegates to sub-agents,
monitors health, escalates to Crown when needed.
He does NOT do the work himself.
"""
from __future__ import annotations

import sqlite3
import threading
import time
from datetime import datetime, timezone

from openclaw_web.agents.message_bus import MessageBus
from openclaw_web.agents.model_router import ModelRouter


# Delegation rules: event → which agent handles it
DELEGATION_MAP = {
    "artifact_submitted": "warden",
    "artifact_survived": "treasurer",
    "security_alert": "warden",
    "royalty_due": "treasurer",
    "guild_dispute": "magistrate",
    "citizenship_appeal": "magistrate",
    "forum_moderation": "magistrate",
    "brief_claimed": None,  # AchillesRun handles directly
}

# Escalation thresholds
ESCALATION_RULES = {
    "warden_timeout": 300,       # 5 min
    "treasurer_large_payment": 0.01,  # > 1% of supply
    "constitutional_question": True,   # Always escalate
    "agent_down": 900,           # 15 min
}


class AchillesRun:
    """
    The Steward of House Bernard.
    Delegates everything. Does not do the work himself.
    """

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.bus = MessageBus(conn)
        self.router = ModelRouter()
        self._running = False
        self._thread = None
        self.name = "achillesrun"

    def start(self) -> None:
        """Start the steward loop in a background thread."""
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        self.bus.heartbeat(self.name)
        self._log("AchillesRun online. Ad Astra Per Aspera.")

    def stop(self) -> None:
        """Stop the steward loop."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=10)
        self._log("AchillesRun shutting down.")

    def _run_loop(self) -> None:
        """Main loop: check messages, delegate, monitor health."""
        while self._running:
            try:
                # Process incoming messages
                messages = self.bus.get_pending(self.name)
                for msg in messages:
                    self._handle_message(msg)

                # Send heartbeat
                self.bus.heartbeat(self.name)

                # Check sub-agent health
                self._check_health()

            except Exception as e:
                self._log(f"Loop error: {e}", level="error")

            time.sleep(5)  # Poll every 5 seconds

    def _handle_message(self, msg: dict) -> None:
        """Route an incoming message to the right handler."""
        msg_type = msg.get("message_type", "")
        payload = msg.get("payload", {})
        msg_uuid = msg.get("msg_uuid", "")

        if msg_type == "task":
            self._delegate_task(msg)
        elif msg_type == "response":
            self._process_response(msg)
        elif msg_type == "alert":
            self._process_alert(msg)
        elif msg_type == "escalation":
            self._handle_escalation(msg)
        elif msg_type == "heartbeat":
            pass  # Just note it

        self.bus.complete(msg_uuid)

    def _delegate_task(self, msg: dict) -> None:
        """Delegate a task to the appropriate sub-agent."""
        payload = msg.get("payload", {})
        action = payload.get("action", "")
        from_agent = msg.get("from_agent", "")

        target = DELEGATION_MAP.get(action)

        if target is None:
            # AchillesRun handles directly
            self._handle_direct(action, payload, from_agent)
        elif target:
            # Delegate to sub-agent
            self.bus.send_task(self.name, target, action, payload)
            self._log(f"Delegated '{action}' → {target}")
        else:
            self._log(f"Unknown action: {action}", level="warning")

    def _handle_direct(self, action: str, payload: dict, from_agent: str) -> None:
        """Handle tasks AchillesRun manages directly."""
        if action == "brief_claimed":
            citizen = payload.get("citizen_id", "?")
            brief = payload.get("brief_id", "?")
            self._log(f"Brief {brief} claimed by {citizen}")
            # Post to Agent Log forum
            self._post_to_forum(
                f"Brief {brief} has been claimed by citizen {citizen}."
            )

    def _process_response(self, msg: dict) -> None:
        """Process a response from a sub-agent."""
        payload = msg.get("payload", {})
        from_agent = msg.get("from_agent", "")
        result = payload.get("result", {})
        action = result.get("action", "completed")

        self._log(f"Response from {from_agent}: {action}")

        # If an artifact survived, notify treasurer
        if result.get("survived"):
            self.bus.send_task(
                self.name, "treasurer", "compute_royalty",
                {"artifact": result.get("artifact"), "citizen": result.get("citizen")}
            )

    def _process_alert(self, msg: dict) -> None:
        """Process an alert from a sub-agent."""
        payload = msg.get("payload", {})
        from_agent = msg.get("from_agent", "")
        severity = payload.get("severity", "normal")
        message = payload.get("message", "")

        self._log(f"ALERT [{severity}] from {from_agent}: {message}")

        if severity in ("high", "emergency"):
            self._post_to_forum(f"⚠ ALERT from {from_agent}: {message}")

    def _handle_escalation(self, msg: dict) -> None:
        """Handle escalation — this goes to the Crown."""
        payload = msg.get("payload", {})
        from_agent = msg.get("from_agent", "")
        reason = payload.get("reason", "Unknown")

        self._log(f"ESCALATION from {from_agent}: {reason}", level="critical")
        self._post_to_forum(
            f"🚨 ESCALATION from {from_agent}: {reason}\n\n"
            f"Crown attention required."
        )

    def _check_health(self) -> None:
        """Check sub-agent heartbeats, escalate if needed."""
        statuses = self.bus.get_all_status()
        now = datetime.now(timezone.utc)

        for agent in statuses:
            name = agent["agent_name"]
            if name == self.name:
                continue

            last_seen = datetime.fromisoformat(
                agent["last_seen"].replace("Z", "+00:00")
            )
            gap = (now - last_seen).total_seconds()

            if gap > ESCALATION_RULES["agent_down"]:
                if agent["status"] != "offline":
                    self.conn.execute(
                        "UPDATE agent_heartbeats SET status='offline' WHERE agent_name=?",
                        (name,)
                    )
                    self.conn.commit()
                    self._log(f"Agent {name} OFFLINE ({gap:.0f}s)", level="critical")
                    self._post_to_forum(f"🔴 Agent {name} is offline. Crown notified.")
            elif gap > ESCALATION_RULES["warden_timeout"]:
                if agent["status"] != "degraded":
                    self.conn.execute(
                        "UPDATE agent_heartbeats SET status='degraded' WHERE agent_name=?",
                        (name,)
                    )
                    self.conn.commit()
                    self._log(f"Agent {name} degraded ({gap:.0f}s)", level="warning")

    def _post_to_forum(self, message: str) -> None:
        """Post an update to the Agent Log forum topic."""
        from openclaw_web import database as db_module
        try:
            # Find the Agent Log topic
            topics = db_module.list_topics(self.conn)
            agent_topic = next(
                (t for t in topics if t["name"] == "Agent Log"), None
            )
            if not agent_topic:
                return

            # Find or create the daily thread
            today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
            threads = db_module.list_threads(self.conn, agent_topic["id"])
            daily = next(
                (t for t in threads if today in t["title"]), None
            )

            if daily:
                db_module.create_post(
                    self.conn, daily["id"], "SYSTEM-ACHILLES", message, is_agent=True
                )
            else:
                db_module.create_thread(
                    self.conn, agent_topic["id"],
                    f"Agent Log — {today}", message, "SYSTEM-ACHILLES"
                )
        except Exception as e:
            print(f"[ACHILLES] Forum post failed: {e}")

    def _log(self, message: str, level: str = "info") -> None:
        """Internal logging."""
        ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
        prefix = {"info": "ℹ", "warning": "⚠", "error": "❌", "critical": "🚨"}
        print(f"[{ts}] {prefix.get(level, 'ℹ')} ACHILLES: {message}")

    # ── Public API for web routes ──

    def submit_artifact(self, citizen_id: str, filename: str,
                        artifact_hash: str, brief_id: str = "") -> str:
        """Called by web app when citizen submits an artifact."""
        self.bus.send_task(
            "web", self.name, "artifact_submitted",
            {
                "citizen_id": citizen_id,
                "filename": filename,
                "artifact_hash": artifact_hash,
                "brief_id": brief_id,
            }
        )
        return "queued"

    def claim_brief(self, citizen_id: str, brief_id: str) -> str:
        """Called by web app when citizen claims a brief."""
        self.bus.send_task(
            "web", self.name, "brief_claimed",
            {"citizen_id": citizen_id, "brief_id": brief_id}
        )
        return "claimed"
