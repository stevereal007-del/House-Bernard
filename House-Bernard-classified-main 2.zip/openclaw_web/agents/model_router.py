"""
House Bernard — Model Router
Routes inference requests to the appropriate model.
Routine tasks → Ollama (local, free, fast)
Complex tasks → Claude API (smart, costs money)
Emergency → Claude API + Crown notification
"""
from __future__ import annotations

import json
import os
from typing import Optional

ROUTINE_TASKS = {
    "classify_submission",
    "moderate_forum_post",
    "generate_heartbeat_report",
    "summarize_thread",
    "format_status_update",
    "parse_artifact_manifest",
}

COMPLEX_TASKS = {
    "evaluate_constitutional_question",
    "analyze_security_threat",
    "draft_governance_proposal",
    "resolve_guild_dispute",
    "evaluate_artifact_novelty",
    "write_research_brief",
    "compute_complex_royalty",
}


class ModelRouter:
    """Routes inference to local (Ollama) or remote (Claude) models."""

    def __init__(self, ollama_url: str = "http://localhost:11434",
                 ollama_model: str = "mistral",
                 claude_model: str = "claude-sonnet-4-20250514"):
        self.ollama_url = ollama_url
        self.ollama_model = ollama_model
        self.claude_model = claude_model
        self._claude_key = os.environ.get("ANTHROPIC_API_KEY", "")

    def route(self, task_type: str, prompt: str,
              system: str = "You are a House Bernard agent.") -> str:
        """Route a task to the appropriate model and return the response."""
        if task_type in ROUTINE_TASKS:
            return self._call_ollama(prompt, system)
        elif task_type in COMPLEX_TASKS:
            return self._call_claude(prompt, system)
        else:
            # Unknown → try local first, flag for review
            try:
                return self._call_ollama(prompt, system)
            except Exception:
                return self._call_claude(prompt, system)

    def _call_ollama(self, prompt: str, system: str) -> str:
        """Call local Ollama instance."""
        try:
            import urllib.request
            data = json.dumps({
                "model": self.ollama_model,
                "system": system,
                "prompt": prompt,
                "stream": False,
            }).encode("utf-8")

            req = urllib.request.Request(
                f"{self.ollama_url}/api/generate",
                data=data,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=60) as resp:
                result = json.loads(resp.read())
                return result.get("response", "")
        except Exception as e:
            return f"[OLLAMA_UNAVAILABLE] {e}"

    def _call_claude(self, prompt: str, system: str) -> str:
        """Call Claude API."""
        if not self._claude_key:
            return "[CLAUDE_NO_KEY] Set ANTHROPIC_API_KEY environment variable"
        try:
            import urllib.request
            data = json.dumps({
                "model": self.claude_model,
                "max_tokens": 2048,
                "system": system,
                "messages": [{"role": "user", "content": prompt}],
            }).encode("utf-8")

            req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages",
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "x-api-key": self._claude_key,
                    "anthropic-version": "2023-06-01",
                },
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                result = json.loads(resp.read())
                return result["content"][0]["text"]
        except Exception as e:
            return f"[CLAUDE_ERROR] {e}"

    def is_local_available(self) -> bool:
        """Check if Ollama is running."""
        try:
            import urllib.request
            urllib.request.urlopen(f"{self.ollama_url}/api/tags", timeout=5)
            return True
        except Exception:
            return False

    def is_claude_available(self) -> bool:
        """Check if Claude API key is configured."""
        return bool(self._claude_key)
