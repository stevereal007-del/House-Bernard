"""
House Bernard — Authentication (Phase 0)
Simple token-based auth. Phase 1 will add Solana wallet signatures.
"""
from __future__ import annotations

import sqlite3
from typing import Optional

from openclaw_web import database as db


def authenticate(conn: sqlite3.Connection, token: str) -> Optional[dict]:
    """Authenticate a citizen by their auth token."""
    if not token:
        return None
    return db.get_citizen_by_token(conn, token)


def register(conn: sqlite3.Connection, alias: str, wallet: str = "") -> dict:
    """Register a new citizen. Returns citizen dict with auth token."""
    # Check if alias already taken
    existing = db.get_citizen_by_alias(conn, alias)
    if existing:
        return {"error": "Alias already taken"}

    cid = db.create_citizen(conn, alias, wallet)
    citizen = db.get_citizen(conn, cid)
    return citizen
