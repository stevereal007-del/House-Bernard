"""
House Bernard Platform — Database Layer
SQLite with WAL mode. Zero-config, runs on Beelink.
"""
from __future__ import annotations

import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

DB_PATH = Path.home() / ".openclaw" / "hb_platform.db"
MIGRATIONS_DIR = Path(__file__).parent / "migrations"


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def get_db(db_path: Optional[Path] = None) -> sqlite3.Connection:
    """Get a database connection with WAL mode and foreign keys."""
    path = db_path or DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def run_migrations(conn: sqlite3.Connection) -> None:
    """Run all SQL migration files in order."""
    for sql_file in sorted(MIGRATIONS_DIR.glob("*.sql")):
        conn.executescript(sql_file.read_text(encoding="utf-8"))
    conn.commit()


def init_db(db_path: Optional[Path] = None) -> sqlite3.Connection:
    """Initialize database with all migrations."""
    conn = get_db(db_path)
    run_migrations(conn)
    return conn


# ── Citizens ──────────────────────────────────────────

def create_citizen(conn: sqlite3.Connection, alias: str,
                   wallet: str = "", tier: str = "visitor") -> str:
    cid = f"HB-CIT-{uuid.uuid4().hex[:8].upper()}"
    conn.execute(
        "INSERT INTO citizens (id, alias, wallet_address, tier, auth_token, joined_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (cid, alias, wallet, tier, uuid.uuid4().hex, _now())
    )
    conn.commit()
    return cid


def get_citizen(conn: sqlite3.Connection, citizen_id: str) -> Optional[dict]:
    row = conn.execute("SELECT * FROM citizens WHERE id=?", (citizen_id,)).fetchone()
    return dict(row) if row else None


def get_citizen_by_alias(conn: sqlite3.Connection, alias: str) -> Optional[dict]:
    row = conn.execute("SELECT * FROM citizens WHERE alias=?", (alias,)).fetchone()
    return dict(row) if row else None


def get_citizen_by_token(conn: sqlite3.Connection, token: str) -> Optional[dict]:
    row = conn.execute("SELECT * FROM citizens WHERE auth_token=?", (token,)).fetchone()
    return dict(row) if row else None


def list_citizens(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute("SELECT * FROM citizens ORDER BY joined_at").fetchall()
    return [dict(r) for r in rows]


# ── Forum ─────────────────────────────────────────────

def list_topics(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute(
        "SELECT t.*, COUNT(th.id) as thread_count "
        "FROM forum_topics t LEFT JOIN forum_threads th ON th.topic_id = t.id "
        "GROUP BY t.id ORDER BY t.sort_order, t.name"
    ).fetchall()
    return [dict(r) for r in rows]


def get_topic(conn: sqlite3.Connection, topic_id: int) -> Optional[dict]:
    row = conn.execute("SELECT * FROM forum_topics WHERE id=?", (topic_id,)).fetchone()
    return dict(row) if row else None


def list_threads(conn: sqlite3.Connection, topic_id: int) -> list[dict]:
    rows = conn.execute(
        "SELECT t.*, c.alias as author_name, "
        "(SELECT COUNT(*) FROM forum_posts WHERE thread_id=t.id) as post_count "
        "FROM forum_threads t JOIN citizens c ON c.id = t.author_id "
        "WHERE t.topic_id=? "
        "ORDER BY t.pinned DESC, t.last_post_at DESC",
        (topic_id,)
    ).fetchall()
    return [dict(r) for r in rows]


def get_thread(conn: sqlite3.Connection, thread_id: int) -> Optional[dict]:
    row = conn.execute(
        "SELECT t.*, c.alias as author_name "
        "FROM forum_threads t JOIN citizens c ON c.id = t.author_id "
        "WHERE t.id=?", (thread_id,)
    ).fetchone()
    return dict(row) if row else None


def list_posts(conn: sqlite3.Connection, thread_id: int) -> list[dict]:
    rows = conn.execute(
        "SELECT p.*, c.alias as author_name, c.tier as author_tier "
        "FROM forum_posts p JOIN citizens c ON c.id = p.author_id "
        "WHERE p.thread_id=? ORDER BY p.created_at",
        (thread_id,)
    ).fetchall()
    return [dict(r) for r in rows]


def create_thread(conn: sqlite3.Connection, topic_id: int,
                  title: str, body: str, author_id: str) -> int:
    now = _now()
    cur = conn.execute(
        "INSERT INTO forum_threads (topic_id, title, author_id, created_at, last_post_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (topic_id, title, author_id, now, now)
    )
    thread_id = cur.lastrowid
    conn.execute(
        "INSERT INTO forum_posts (thread_id, author_id, body, created_at) "
        "VALUES (?, ?, ?, ?)",
        (thread_id, author_id, body, now)
    )
    conn.commit()
    return thread_id


def create_post(conn: sqlite3.Connection, thread_id: int,
                author_id: str, body: str, is_agent: bool = False) -> int:
    now = _now()
    cur = conn.execute(
        "INSERT INTO forum_posts (thread_id, author_id, body, created_at, is_agent) "
        "VALUES (?, ?, ?, ?, ?)",
        (thread_id, author_id, body, now, int(is_agent))
    )
    conn.execute(
        "UPDATE forum_threads SET last_post_at=? WHERE id=?",
        (now, thread_id)
    )
    conn.commit()
    return cur.lastrowid


# ── Briefs ────────────────────────────────────────────

def list_briefs(conn: sqlite3.Connection, status: str = "open") -> list[dict]:
    rows = conn.execute(
        "SELECT b.*, c.alias as claimed_by_name "
        "FROM briefs b LEFT JOIN citizens c ON c.id = b.claimed_by "
        "WHERE b.status=? ORDER BY b.created_at DESC",
        (status,)
    ).fetchall()
    return [dict(r) for r in rows]


def get_brief(conn: sqlite3.Connection, brief_id: str) -> Optional[dict]:
    row = conn.execute("SELECT * FROM briefs WHERE id=?", (brief_id,)).fetchone()
    return dict(row) if row else None


def create_brief(conn: sqlite3.Connection, title: str, description: str,
                 lab: str = "lab_a", reward_tier: int = 1, deadline: str = "") -> str:
    bid = f"HB-BRIEF-{uuid.uuid4().hex[:6].upper()}"
    conn.execute(
        "INSERT INTO briefs (id, title, description, lab, reward_tier, deadline, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (bid, title, description, lab, reward_tier, deadline or None, _now())
    )
    conn.commit()
    return bid


def claim_brief(conn: sqlite3.Connection, brief_id: str, citizen_id: str) -> bool:
    cur = conn.execute(
        "UPDATE briefs SET status='claimed', claimed_by=? "
        "WHERE id=? AND status='open'",
        (citizen_id, brief_id)
    )
    conn.commit()
    return cur.rowcount > 0


# ── Submissions ───────────────────────────────────────

def create_submission(conn: sqlite3.Connection, citizen_id: str,
                      filename: str, artifact_hash: str,
                      brief_id: str = "") -> int:
    cur = conn.execute(
        "INSERT INTO submissions (brief_id, citizen_id, filename, artifact_hash, submitted_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (brief_id or None, citizen_id, filename, artifact_hash, _now())
    )
    conn.commit()
    return cur.lastrowid


def update_submission(conn: sqlite3.Connection, sub_id: int,
                      status: str, tier_reached: str = "") -> None:
    conn.execute(
        "UPDATE submissions SET status=?, verdict_at=?, tier_reached=? WHERE id=?",
        (status, _now(), tier_reached or None, sub_id)
    )
    conn.commit()


def list_submissions(conn: sqlite3.Connection, citizen_id: str = "") -> list[dict]:
    if citizen_id:
        rows = conn.execute(
            "SELECT s.*, c.alias as citizen_name "
            "FROM submissions s JOIN citizens c ON c.id = s.citizen_id "
            "WHERE s.citizen_id=? ORDER BY s.submitted_at DESC",
            (citizen_id,)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT s.*, c.alias as citizen_name "
            "FROM submissions s JOIN citizens c ON c.id = s.citizen_id "
            "ORDER BY s.submitted_at DESC LIMIT 50"
        ).fetchall()
    return [dict(r) for r in rows]


# ── Agent Messages ────────────────────────────────────

def send_message(conn: sqlite3.Connection, from_agent: str, to_agent: str,
                 message_type: str, payload: dict,
                 priority: str = "normal") -> str:
    import json
    msg_uuid = f"msg-{uuid.uuid4().hex[:12]}"
    conn.execute(
        "INSERT INTO agent_messages "
        "(msg_uuid, from_agent, to_agent, message_type, payload, priority, status, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)",
        (msg_uuid, from_agent, to_agent, message_type, json.dumps(payload), priority, _now())
    )
    conn.commit()
    return msg_uuid


def get_pending_messages(conn: sqlite3.Connection, agent: str) -> list[dict]:
    import json
    rows = conn.execute(
        "SELECT * FROM agent_messages WHERE to_agent=? AND status='pending' "
        "ORDER BY CASE priority "
        "  WHEN 'emergency' THEN 0 WHEN 'high' THEN 1 "
        "  WHEN 'normal' THEN 2 WHEN 'low' THEN 3 END, created_at",
        (agent,)
    ).fetchall()
    results = []
    for r in rows:
        d = dict(r)
        d["payload"] = json.loads(d["payload"])
        results.append(d)
    return results


def complete_message(conn: sqlite3.Connection, msg_uuid: str,
                     status: str = "completed") -> None:
    conn.execute(
        "UPDATE agent_messages SET status=?, processed_at=? WHERE msg_uuid=?",
        (status, _now(), msg_uuid)
    )
    conn.commit()


# ── Heartbeats ────────────────────────────────────────

def update_heartbeat(conn: sqlite3.Connection, agent_name: str) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO agent_heartbeats (agent_name, last_seen, status) "
        "VALUES (?, ?, 'online')",
        (agent_name, _now())
    )
    conn.commit()


def get_agent_status(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute("SELECT * FROM agent_heartbeats").fetchall()
    return [dict(r) for r in rows]
