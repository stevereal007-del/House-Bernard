"""
House Bernard Platform — Configuration
"""
from pathlib import Path

# Paths
REPO_ROOT = Path(__file__).resolve().parents[1]
PLATFORM_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = PLATFORM_DIR / "templates"
STATIC_DIR = PLATFORM_DIR / "static"
UPLOAD_DIR = Path.home() / ".openclaw" / "inbox"
DB_PATH = Path.home() / ".openclaw" / "hb_platform.db"

# Server
HOST = "0.0.0.0"
PORT = 8000
DEBUG = True

# Agent model routing
OLLAMA_URL = "http://localhost:11434"
OLLAMA_MODEL = "mistral"  # Default local model
CLAUDE_MODEL = "claude-sonnet-4-20250514"

# Agent timing
HEARTBEAT_INTERVAL = 60        # seconds
HEARTBEAT_TIMEOUT = 300        # 5 min before degraded
HEARTBEAT_DEAD = 900           # 15 min before offline → escalate to Crown

# Limits
MAX_UPLOAD_MB = 50
MAX_POST_LENGTH = 10000
THREADS_PER_PAGE = 25
POSTS_PER_PAGE = 50
