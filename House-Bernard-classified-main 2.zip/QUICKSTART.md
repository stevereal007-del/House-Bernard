# House Bernard — Quick Start (Phase 0)

Get Lab A Phase 0 running in under 30 minutes.

## Prerequisites

- Ubuntu/Linux machine (Beelink EQ13 recommended)
- Docker installed
- Python 3.10+
- 16 GB RAM minimum

## Installation

### 1. Clone Repository

```bash
cd ~
git clone <CLASSIFIED_REPO_URL> House-Bernard
cd House-Bernard
```

### 2. Install Dependencies

```bash
sudo apt install -y docker.io
sudo usermod -aG docker $USER
newgrp docker
pip3 install watchdog --break-system-packages
```

### 3. Create Runtime Directories

```bash
mkdir -p ~/.openclaw/lab_a/{results,survivors}
mkdir -p ~/.openclaw/{inbox,sandbox,purgatory,quarantine,nullsink}
```

### 4. Pull and Pin Docker Image

```bash
docker pull python:3.10.15-alpine
docker inspect --format='{{index .RepoDigests 0}}' python:3.10.15-alpine
```

### 5. Start Airlock Monitor

```bash
cd ~/House-Bernard/airlock
python3 airlock_monitor.py
```

Leave running in a terminal (or install the systemd service: `airlock/airlock.service`).

### 6. Run All Tests

```bash
cd ~/House-Bernard
python3 run_tests.py
```

### 7. Submit a SAIF Artifact

```bash
cp my_artifact.zip ~/.openclaw/inbox/
```

### 8. Check Results

```bash
cat ~/.openclaw/lab_a/results/ELIMINATION_LOG.jsonl
ls ~/.openclaw/lab_a/survivors/
```

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Docker permission denied | `sudo usermod -aG docker $USER && newgrp docker` |
| Executioner not found | Verify `executioner/executioner_production.py` exists |
| No module 'watchdog' | `pip3 install watchdog --break-system-packages` |
| CAA tests fail with import error | Run from repo root: `python3 caa/test_caa.py` |

## Phase 0 Complete When

- One survivor passes T0–T4
- One gene extracted and documented in `ledger/GENE_REGISTRY.md`
- All test suites pass (`python3 run_tests.py`)
