# Changelog (Classified)

**CLASSIFICATION: CROWN EYES ONLY**

## [0.3.0] — 2026-02-14

### Added
- `examples/sample_artifact/` — working SAIF v1.1 artifact with selftest
- `hooks/pre-commit` — pre-commit hook (secrets, pycache, tests, sync check)
- `deployment_config.template.json` — config template for wallets and RPC
- `Makefile` — `make test`, `make build-site`, `make sync-check`, `make security-scan`
- `docker-compose.yml` + Dockerfiles — local dev stack for Beelink (airlock, executioner, treasury, site builder)
- `.dockerignore` — excludes Section 9 and secrets from Docker builds

### Changed
- All engines refactored to import from `hb_utils.py` (19 duplicate definitions eliminated)
- Treasury, guild, ISD, and support modules now use canonical shared utilities

## [0.2.0] — 2026-02-14

### Added
- `hb_utils.py`, `run_tests.py`, `scripts/check_sync.py`
- `CHANGELOG.md`, `LICENSE`, `pyproject.toml`
- `__init__.py` for all Python packages

### Fixed
- Governor → Crown in all code, wallet paths, env vars
- CAA test suite runs standalone
- `__pycache__` purged, `.gitignore` expanded

## [0.1.0] — 2026-02-08

### Added
- Initial classified repository with all modules
