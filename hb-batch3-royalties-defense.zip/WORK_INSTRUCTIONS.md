# WORK INSTRUCTIONS — Batch 3: ROYALTIES.md Fix + DEFENSE.md Audit

## Step 0: Get the Patch File

```bash
cd ~/House-Bernard
git pull origin main
ls hb-batch3-royalties-defense.zip
```

If not in repo root:
```bash
curl -L -o hb-batch3-royalties-defense.zip \
  "https://github.com/stevereal007-del/House-Bernard/raw/main/hb-batch3-royalties-defense.zip"
```

## Step 1: Extract

```bash
mkdir -p ~/hb-batch3-work
cd ~/hb-batch3-work
unzip ~/House-Bernard/hb-batch3-royalties-defense.zip
```

Files:
- `WORK_INSTRUCTIONS.md` — this file (do not commit)
- `ROYALTIES.md` — fixed (replaces existing)
- `TREASURY.md` — fixed (replaces existing)
- `QUICKSTART.md` — fixed (replaces existing)
- `FINDINGS_ROYALTIES.md` — audit report (do not commit)
- `FINDINGS_DEFENSE.md` — audit report (do not commit)

## Step 2: Housekeeping — Remove Batch 2 Patch Zip

```bash
cd ~/House-Bernard
git rm hb-batch2-readme-philosophy-council.zip 2>/dev/null || true
```

## Step 3: Apply Fixes

```bash
cd ~/House-Bernard

cp ~/hb-batch3-work/ROYALTIES.md ./ROYALTIES.md
cp ~/hb-batch3-work/TREASURY.md ./TREASURY.md
cp ~/hb-batch3-work/QUICKSTART.md ./QUICKSTART.md
```

## Step 4: Clean Up Patch Zip

```bash
git rm hb-batch3-royalties-defense.zip 2>/dev/null || true
```

## Step 5: Commit

```bash
git add ROYALTIES.md TREASURY.md QUICKSTART.md
git status
git commit -m "fix(royalties): decouple tier thresholds from phantom T-levels

Tier thresholds now reference Executioner + qualification criteria instead
of specific T-numbers. T5 and T6 never existed in the Executioner (T0-T4
only). This cross-cutting fix touches three files:

ROYALTIES.md:
- Spark: 'Passes T3' → 'Passes full Executioner gauntlet (T0-T4)'
- Flame: 'Passes T5 + splice' → 'Passes Executioner + successful splice'
- Furnace-Forged: 'Passes T6 + Ledger' → 'Passes Executioner + gene registered in Ledger'
- Removed T-numbers from base payment table headers
- Updated task template tier eligibility block
- Added Last Updated date for consistency

TREASURY.md:
- Same tier table fix (lines 78-80)

QUICKSTART.md:
- 'Phase 1 (T5 adversarial testing)' → 'Phase 1 (expanded adversarial testing, Splicer integration)'"
```

## Step 6: Push

```bash
git push origin main
```

## Step 7: Verify

```bash
# No T5/T6 anywhere in the three files
grep "T5\|T6" ROYALTIES.md && echo "FAIL" || echo "PASS: ROYALTIES clean"
grep "T5\|T6" TREASURY.md && echo "FAIL" || echo "PASS: TREASURY clean"
grep "T5\|T6" QUICKSTART.md && echo "FAIL" || echo "PASS: QUICKSTART clean"

# Tier thresholds use Executioner language
grep "Passes full Executioner gauntlet" ROYALTIES.md && echo "PASS: Spark" || echo "FAIL"
grep "Passes Executioner + successful splice" ROYALTIES.md && echo "PASS: Flame" || echo "FAIL"
grep "Passes Executioner + gene registered" ROYALTIES.md && echo "PASS: Furnace" || echo "FAIL"

# QUICKSTART Phase 1 line updated
grep "expanded adversarial testing" QUICKSTART.md && echo "PASS: Phase 1" || echo "FAIL"

# Last Updated added to ROYALTIES
grep "Last Updated" ROYALTIES.md && echo "PASS: date added" || echo "FAIL"
```

All 8 checks should PASS.

## What NOT to commit

- `WORK_INSTRUCTIONS.md`
- `FINDINGS_ROYALTIES.md`
- `FINDINGS_DEFENSE.md`

---

## What Changed (summary)

| File | Action | Finding |
|------|--------|---------|
| `ROYALTIES.md` | **REPLACED** | Decoupled all tier thresholds from T-numbers; added Last Updated date |
| `TREASURY.md` | **REPLACED** | Same tier table fix |
| `QUICKSTART.md` | **REPLACED** | Removed phantom T5 from Phase 1 line |
| `DEFENSE.md` | No changes | Passed audit clean |

## Design Decision Applied

**Tier thresholds are now defined by qualification criteria, not test-level numbers.**

The Executioner runs T0–T4. Those are implementation details. Tiers are earned by what your contribution *achieves*: surviving the gauntlet, producing a gene, getting registered in the Ledger, or being designated by the Governor. If T5+ is added later, the tier definitions don't break — they just get harder to reach.
