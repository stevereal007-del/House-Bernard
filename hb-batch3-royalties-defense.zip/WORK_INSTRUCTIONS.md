# WORK INSTRUCTIONS — Batch 3: ROYALTIES.md + DEFENSE.md Audit

## What's in this batch

| File | Action | Details |
|------|--------|---------|
| `ROYALTIES.md` | **PENDING FIX** | 1 critical, 1 medium, 1 minor — waiting on Governor decision |
| `DEFENSE.md` | No changes | Passed audit — 0 bugs |

## Housekeeping: Remove Batch 2 patch zip

The batch 2 patch zip is still in the repo. Clean it up:

```bash
cd ~/House-Bernard
git rm hb-batch2-readme-philosophy-council.zip
git commit -m "chore: remove batch2 patch zip"
git push origin main
```

## ROYALTIES.md — BLOCKED: Governor Decision Required

The critical finding (F1) requires a design decision before fixes can be applied. The Executioner only has T0–T4, but ROYALTIES.md maps tiers to T3/T5/T6.

### The three options:

**Option A — Map tiers to existing T0–T4 (simplest):**
- Spark = Passes T2 (Degradation)
- Flame = Passes T4 (full gauntlet) + successful splice
- Furnace-Forged = Passes T4 + gene registered in Ledger
- Invariant = Governor-designated (unchanged)
- Pro: Accurate to current code. No phantom levels.
- Con: Loses the idea that higher tiers require harder tests.

**Option B — T5/T6 are planned future tiers (preserve intent):**
- Keep T5/T6 references but add a note: "T5–T6 are Phase 1 extensions. Until implemented, Flame requires T4 + splice, Furnace-Forged requires T4 + Ledger registration."
- Pro: Preserves your roadmap vision.
- Con: Documents things that don't exist yet as if they do.

**Option C — Decouple tiers from T-numbers entirely (cleanest):**
- Spark = "Passes full Executioner gauntlet (T0–T4)"
- Flame = "Passes Executioner + successful Splicer extraction"
- Furnace-Forged = "Passes Executioner + gene registered in Ledger"
- Invariant = "Governor-designated"
- Pro: Future-proof. Adding T5/T6 later doesn't break docs.
- Con: Loses the specific T-number shorthand.

### Once the Governor decides:

Fixes will be applied to:
- ROYALTIES.md (lines 17, 28, 39, 63, 170, 186, 187, 188)
- TREASURY.md (lines 78–80)
- QUICKSTART.md (line 128)

The fix will be packaged in the next batch.

### ROYALTIES.md F2 fix (medium — can apply now):

Line 17 parenthetical "(determinism + basic harness)" does not match T3's actual function (Compaction). This will be corrected as part of the F1 fix regardless of which option is chosen.

### ROYALTIES.md F3 fix (minor — can apply now):

Add `*Last Updated: February 2025*` before line 269 for consistency with other governance docs.

## DEFENSE.md — NO CHANGES

Passed audit. 0 bugs. 1 advisory note about undocumented "OpenClaw hijack, ClawHub malware" references — no action needed.

---

## Audit Progress After This Batch

| File | Status |
|------|--------|
| README.md | ✅ FIXED (Batch 2) |
| PHILOSOPHY.md | ✅ CLEAN (Batch 2) |
| COUNCIL.md | ✅ CLEAN (Batch 2) |
| TREASURY.md | ✅ CLEAN (Batch 1) |
| ROYALTIES.md | ⚠️ BLOCKED — waiting on Governor T-level decision |
| DEFENSE.md | ✅ CLEAN (this batch) |
| QUICKSTART.md | ⏳ NEXT (has T5 reference — will fix with ROYALTIES) |
| .gitignore | ⏳ PENDING |
| airlock/ | ⏳ PENDING |
| executioner/ | ⏳ PENDING |
| splicer/ | ⏳ PENDING |
| ledger/ | ⏳ PENDING |
| openclaw/ | ⏳ PENDING |
| treasury/ | ✅ DONE (Batch 1) |
| security/ | ⏳ PENDING |
| infrastructure/ | ⏳ PENDING |
| lab_b/ | ⏳ PENDING |
