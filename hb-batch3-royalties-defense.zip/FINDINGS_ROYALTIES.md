# Red Team Findings: ROYALTIES.md

**Auditor:** Claude (Bernardian Council)
**Date:** 2025-02-08
**Verdict:** 1 CRITICAL bug (cross-cutting), 1 MEDIUM, 1 MINOR

---

## F1. CRITICAL: Tier thresholds reference phantom test levels T5 and T6

The Executioner implements T0–T4 only. ROYALTIES.md maps tiers to test levels that do not exist:

| Tier | ROYALTIES.md says | Executioner reality |
|------|-------------------|---------------------|
| Spark | "Passes T3" | T3 exists (Compaction) — but Spark's description says "determinism + basic harness" which sounds like T0–T1, not T3 |
| Flame | "Passes T5" | T5 DOES NOT EXIST |
| Furnace-Forged | "Passes T6" | T6 DOES NOT EXIST |

**Affected lines:** 17, 28, 39, 63, 170, 186, 187, 188

**Same bug appears in:**
- TREASURY.md lines 78–80
- QUICKSTART.md line 128 ("Phase 1 (T5 adversarial testing)")

**Decision required from Governor:** Pick one of these resolutions:

**Option A — Map tiers to existing T0–T4:**
- Spark = Passes T2 (survives degradation)
- Flame = Passes T4 + successful splice
- Furnace-Forged = Passes T4 + gene registered in Ledger
- Invariant = Governor-designated (unchanged)

**Option B — T5/T6 are planned future tiers (document the intent):**
- Add a note: "T5 and T6 are planned Phase 1 extensions. Until implemented, Flame requires T4 + splice, Furnace-Forged requires T4 + Ledger registration."
- Update QUICKSTART.md line 128 to match.

**Option C — Redefine tier thresholds as composite criteria (decouple from T-numbers):**
- Spark = "Passes full Executioner gauntlet (T0–T4)"
- Flame = "Passes Executioner + successful Splicer gene extraction"
- Furnace-Forged = "Passes Executioner + gene registered in Ledger"
- This avoids needing T5/T6 entirely.

## F2. MEDIUM: Spark description contradicts its own threshold

**Line 17:** Threshold says "Passes T3 (determinism + basic harness)"
**Line 22:** Description says "pass intake, policy, and basic harness tests"

But T3 in the Executioner is Compaction (forced target_bytes + audit) — not "determinism + basic harness." The parenthetical is wrong regardless of which T-level mapping you choose.

**Fix:** Remove the parenthetical explanation and let the T-level speak for itself, or rewrite to match the actual test.

## F3. MINOR: No "Last Updated" date matches current version

**Line 269:** Shows "Document Version: 2.0" but no "Last Updated" date (unlike PHILOSOPHY.md and COUNCIL.md which have "Last Updated: February 2025").

**Fix:** Add `*Last Updated: February 2025*` before the version line for consistency.

---

## Cross-Reference Checks Passed

| Claim | Verified Against |
|-------|-----------------|
| 5% burn fee on royalties | TREASURY.md (confirmed) |
| Council validation process | COUNCIL.md (confirmed) |
| Furnace-Forged/Invariant need Governor confirmation | COUNCIL.md line 143 (confirmed) |
| Gene registry in ledger/GENE_REGISTRY.md | File exists (confirmed) |
| 100 token minimum payout threshold | Only defined here — no contradiction |
| Lineage depth cap of 2 generations | Only defined here — no contradiction |
| Reputation tiers and decay | Only defined here — no contradiction |
| Security task payment ranges | Only defined here — no contradiction |
| OpenClaw agent eligibility | COUNCIL.md line 105 (confirmed) |

## Structural Review

| Check | Result |
|-------|--------|
| Four tiers clearly defined | ✅ |
| Decay mechanics (3 types) | ✅ Well-designed |
| Revenue attribution model | ✅ Thorough |
| Task template complete | ✅ (except T-level bug) |
| Task lifecycle defined | ✅ |
| Reputation system | ✅ |
| Security task handling | ✅ |
