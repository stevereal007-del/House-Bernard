# Section 9 — Claude Code Work Instructions

**Classification:** CROWN EYES ONLY
**Purpose:** Step-by-step procedures for using Claude Code
on the Beelink EQ13 to build, test, deploy, and maintain
the Section 9 module within the House Bernard repository.
**Audience:** HeliosBlade (Crown / acting Director)
**Version:** 1.0
**Date:** February 2026

-----

## 0. Before You Start

### What This Document Is

This is the hands-on technical companion to
`section_9/WORK_INSTRUCTIONS.md`. That document tells you
WHAT to do. This document tells you HOW to do it with
Claude Code on the Beelink.

### Prerequisites

| Requirement | How to verify |
|-------------|---------------|
| Beelink EQ13 running Ubuntu 24.04 | `lsb_release -a` |
| WSL2 (if running from Windows side) | `wsl --version` |
| Claude Code installed | `claude --version` |
| Node.js 22+ | `node --version` |
| Docker running | `docker ps` |
| Git configured with SSH key | `ssh -T git@github.com` |
| House Bernard repo cloned | `ls ~/House-Bernard/section_9/` |
| Python 3.10+ | `python3 --version` |
| Ollama running with models pulled | `ollama list` |

If any prerequisite fails, run through the deployment
script first: `infrastructure/deployment/deploy_achillesrun.sh`

### Starting Claude Code

From the Beelink terminal (or WSL2 terminal):

```bash
cd ~/House-Bernard
claude
```

Claude Code will open in the repo root. It can see all
files, run commands, edit code, and execute tests. It
cannot access the internet unless you've configured
network access.

### The CLAUDE.md File

Create a `CLAUDE.md` in the repo root if one doesn't exist.
This is Claude Code's project-level instruction file — it
reads this automatically on every session start.

```bash
cat > ~/House-Bernard/CLAUDE.md << 'EOF'
# House Bernard — Claude Code Instructions

## Identity
You are working on the House Bernard repository.
The Governor is HeliosBlade. The agent is AchillesRun.
This is a sovereign research micro-nation's codebase.

## Critical Rules
- NEVER commit directly to main without Governor review
- NEVER expose Section 9 contents in commit messages
- NEVER run weapons code outside Docker sandbox
- NEVER modify CONSTITUTION.md or COVENANT.md without
  explicit Governor instruction
- All Python code must pass security_scanner.py
- All test output goes to JSON format

## Directory Structure
- section_9/          — CLASSIFIED. Crown eyes only.
- security/           — AST scanner, seccomp profiles
- executioner/        — Selection Furnace (T0-T4 testing)
- treasury/           — Token economics engine
- openclaw/           — Agent config and deployment
- lab_b/              — Security genetics laboratory

## Code Standards
- Python 3.10+, type hints on all functions
- No external dependencies not already in the repo
- All output as structured JSON
- All weapons must fail to PASSIVE, never fail to ACTIVE
- Test before commit. Always.

## Section 9 Designations
- Weapons: S9-W-XXX (next available: 007)
- Threats: S9-T-XXX (next available: 001)
- Check section_9/WORK_INSTRUCTIONS.md Appendix C
EOF
```

-----

## 1. Initialize Section 9 (WI-001)

Run this once to stand up Section 9 from the repo.

### Session Script

Open Claude Code and paste:

```
Read section_9/CHARTER.md and section_9/WORK_INSTRUCTIONS.md.
Then execute WI-001 (Standing Up Section 9):

1. Verify the directory structure matches the charter.
   List all files in section_9/ recursively and confirm
   CHARTER.md, README.md, WORK_INSTRUCTIONS.md,
   weapons/REGISTRY.md, operations/LOG.md, and
   intelligence/THREATS.md all exist.

2. Append the Director designation to operations/LOG.md:
   - Crown assumes acting Director role
   - Date: today ISO 8601
   - Duration: until dedicated Director agent appointed
   - Signed: HeliosBlade, Crown

3. Append the initial budget allocation to operations/LOG.md:
   - Budget: 500,000 $HOUSEBERNARD from Governor Reserve
   - Infrastructure: 30%
   - Development: 40%
   - Intelligence: 20%
   - Contingency: 10%
   - Review cycle: quarterly

4. Git add and show me the diff. Do NOT commit yet.
```

Review the diff. If it looks right:

```
Commit with message "sec9: initialize section 9 — director designation and budget"
```

**Commit message convention for Section 9:**
Always prefix with `sec9:` — this makes it easy to filter
Section 9 activity in git log. Keep messages vague enough
that they don't reveal operational details. Good: `sec9: add
passive monitoring capability`. Bad: `sec9: add honeypot
that catches Sybil attackers using fake briefs`.

-----

## 2. Build a Weapon (WI-002)

This is the core development workflow. Each weapon follows
the same pattern. Here's the full Claude Code session for
building S9-W-001 (Tripwire Alpha) as the reference
example. Adapt for all subsequent weapons.

### Phase 1 — Design Doc

```
Read section_9/CHARTER.md Section IV (Weapons Classification)
and section_9/weapons/REGISTRY.md.

Create the design document for S9-W-001 Tripwire Alpha:
- Class I (Passive)
- Purpose: Monitor Airlock submission logs for anomalous
  patterns that indicate probing, flooding, or
  reconnaissance
- It should analyze airlock_monitor.py log output and
  flag anomalies based on:
  * Submission rate per identity exceeding 3x the
    rolling 7-day average
  * Cluster detection: multiple identities submitting
    structurally similar artifacts within a short window
  * Time-of-day anomalies: submissions at unusual hours
    relative to the contributor's established pattern
  * Sequential probing: submissions that systematically
    test boundary conditions (incrementing sizes,
    rotating banned imports, etc.)
- Inputs: Airlock log files (JSON lines)
- Outputs: Alert JSON to section_9/intelligence/
- Must run on the Beelink without starving other processes
  (< 100MB RAM, < 5% CPU sustained)
- Must fail to passive (if it crashes, no alerts fire —
  it does not block the Airlock)

Write the design doc to:
section_9/weapons/S9-W-001_tripwire_alpha.md

Use the template from WORK_INSTRUCTIONS.md WI-002 Step 2.
```

### Phase 2 — Build

```
Now build the weapon. Read the design doc you just wrote
and the existing airlock/airlock_monitor.py for the log
format.

Write section_9/weapons/S9-W-001_tripwire_alpha.py:
- Python 3.10+, type hints on all functions
- No external dependencies beyond stdlib and what's
  already in the repo
- Reads Airlock log JSONL from stdin or file path argument
- Outputs alert JSON to stdout
- Alert format:
  {
    "weapon": "S9-W-001",
    "timestamp": "ISO 8601",
    "alert_type": "rate_spike|cluster|time_anomaly|sequential_probe",
    "severity": "S1|S2|S3",
    "identity": "contributor ID or UNKNOWN",
    "evidence": { ... details ... },
    "recommended_action": "monitor|investigate|escalate"
  }
- Include a --dry-run flag that analyzes but doesn't
  write alerts
- Include a --threshold flag to adjust sensitivity
- Must pass security_scanner.py — run it and show me
  the results

IMPORTANT: This weapon must NOT use any banned imports
from security_scanner.py. Check the BANNED_IMPORTS and
BANNED_FUNCTIONS lists in security/security_scanner.py
before writing any code. If the weapon legitimately needs
a banned import, document the exception in the design doc
and I will sign off.
```

### Phase 3 — Test

```
Create a test file:
section_9/weapons/S9-W-001_test.py

Write tests that cover the full matrix from WI-002 Step 4:

1. Unit tests: each detection function works in isolation
2. Integration test: feed a sample JSONL log, get correct
   alerts
3. False positive test: feed a log of normal activity,
   confirm zero alerts
4. False negative test: feed a log with known anomalies,
   confirm all are caught
5. Resource test: measure peak memory and CPU on a
   1000-line synthetic log
6. Fail-safe test: feed malformed input, confirm it
   fails silently (no alerts, no crash, returns empty)

Run the tests inside Docker to match production:
docker run --rm -v $(pwd):/work -w /work \
  python:3.10.15-alpine \
  python3 -m pytest section_9/weapons/S9-W-001_test.py -v

Show me the full test output.

Then run security_scanner.py against the weapon:
python3 security/security_scanner.py section_9/weapons/S9-W-001_tripwire_alpha.py

Show me the scan result.
```

### Phase 4 — Register

```
Update section_9/weapons/REGISTRY.md:
- Move S9-W-001 from Development Queue to Active Registry
  under Class I
- Status: TESTED
- Authorization: Director (autonomous)
- Last tested: today
- Dependencies: Python 3.10+, Airlock log JSONL

Write test results to:
section_9/weapons/S9-W-001_test_results.json

Update the designation counter in
WORK_INSTRUCTIONS.md Appendix C:
- Weapons next available: 008 (not 007, we just used 007
  if we've built through the queue — actually check the
  current counter and increment by 1)

Show me the diff for all changed files.
```

### Phase 5 — Commit

```
Commit all Section 9 weapon files:
git add section_9/weapons/S9-W-001*
git add section_9/weapons/REGISTRY.md
git add section_9/WORK_INSTRUCTIONS.md
git commit -m "sec9: S9-W-001 tripwire alpha — tested, registered"
```

-----

## 3. Run a Threat Assessment (WI-003)

When you observe something suspicious and need Claude Code
to help analyze it.

### Session Script

```
Read section_9/CHARTER.md Section III (Rules of Engagement)
and section_9/WORK_INSTRUCTIONS.md WI-003.

I've observed the following:
[PASTE YOUR OBSERVATIONS HERE — what happened, when,
where, who reported it]

Execute WI-003:
1. Classify severity (S1-S4) based on the Charter matrix
2. Assess attribution confidence (A1-A4)
3. Determine response posture from the authorization matrix
4. Create a threat entry in section_9/intelligence/THREATS.md
   using the template from WI-003 Step 5
5. If this is S2+, draft a Crown briefing summary (one
   paragraph threat summary, evidence, recommended response,
   risk assessment)
6. Show me the diff before committing
```

### For Automated Threat Detection

If S9-W-001 (Tripwire Alpha) is operational and has
produced an alert:

```
Read the alert at [path to alert JSON].
Cross-reference with section_9/intelligence/THREATS.md
to check if this matches a known threat.

If new threat: execute WI-003 full assessment.
If known threat: update the existing entry with new
activity date and any new TTPs observed.

Show me the diff.
```

-----

## 4. Collect Intelligence (WI-004)

Use Claude Code to run OSINT collection from the Beelink.

### Setting Up Monitoring Scripts

```
Read section_9/WORK_INSTRUCTIONS.md WI-004.

Create section_9/intelligence/osint_monitor.py:
- A lightweight script that checks public sources for
  House Bernard mentions
- Sources to monitor:
  * GitHub: search API for repos mentioning "House Bernard"
    or "$HOUSEBERNARD" (requires GITHUB_TOKEN env var)
  * Domain monitoring: WHOIS lookups for common typosquat
    variations of housebernard (housebernard.io, .com,
    .net, house-bernard.com, etc.)
- Output: JSONL to section_9/intelligence/collection_log.jsonl
- Each entry:
  {
    "source": "github_search|domain_whois",
    "collected": "ISO 8601",
    "content": "...",
    "reliability": "high|medium|low",
    "relevance": "description"
  }
- Must pass security_scanner.py

NOTE: This script DOES need network access (urllib/requests).
This is a documented exception — intelligence collection
requires outbound HTTP. Document the exception in the
script header:
  # SECURITY EXCEPTION: Authorized network access for OSINT
  # collection per Charter Section V. Signed: HeliosBlade
  # This script is NOT a SAIF artifact and does NOT run in
  # the Executioner pipeline. It runs as a Crown tool only.

IMPORTANT: Do not run this through the Executioner or
security_scanner.py's artifact pipeline. This is Crown
tooling, not a contributor submission.
```

### Adding to Cron

```
Read openclaw/openclaw.json for the cron format.

Add an OSINT collection cron job that runs daily at 05:00:
{
  "id": "sec9-osint",
  "schedule": "0 5 * * *",
  "command": "cd ~/House-Bernard && python3 section_9/intelligence/osint_monitor.py",
  "session": "cron:sec9-osint"
}

Show me the diff for openclaw.json.
```

-----

## 5. Build the Dead Man's Switch (WI-008)

This is the most critical weapon. Build it carefully.

### Session Script — Heartbeat Component

```
Read section_9/WORK_INSTRUCTIONS.md WI-008 and
section_9/CHARTER.md Section IV (Class IV weapons).

Design and build the heartbeat component of S9-W-006
Dead Man's Switch.

Part 1 — The heartbeat sender:
Create section_9/weapons/S9-W-006_heartbeat.py

- Sends a heartbeat signal every 12 hours
- Heartbeat content: timestamp + SHA256 hash of current
  THREATS.md + "alive" flag
- Writes heartbeat to a local file:
  section_9/operations/heartbeat.json
  {
    "timestamp": "ISO 8601",
    "threats_hash": "sha256...",
    "status": "alive",
    "sequence": <incrementing integer>
  }
- Also writes to a secondary location (as backup):
  /tmp/hb_sec9_heartbeat.json

Part 2 — The heartbeat monitor:
Create section_9/weapons/S9-W-006_monitor.py

- Checks heartbeat.json on a schedule
- Counts missed heartbeats (heartbeat older than 13 hours
  = one miss, accounting for 1 hour grace)
- Alert thresholds:
  * 3 missed: WARNING — log to operations/LOG.md
  * 5 missed: CRITICAL — send alert to all Crown
    contact methods (for now, write to a designated
    alert file that can be picked up by a notification
    system later)
  * 6 missed: ACTIVATION — execute lockdown sequence

Part 3 — The lockdown sequence (DRY RUN ONLY):
Create section_9/weapons/S9-W-006_lockdown.py

- When activated, this script would:
  1. Write "LOCKDOWN" status to heartbeat.json
  2. Create a cryptographic snapshot:
     tar + SHA256 of the entire repo state
  3. Write the snapshot hash to operations/LOG.md
  4. Write a lockdown notice to a designated file
- FOR NOW: implement everything but make the actual
  lockdown actions no-ops that print what they WOULD do.
  The script must have a --live flag that is required for
  real execution. Without --live, it runs in simulation
  mode and prints actions without executing them.

All three scripts must:
- Have no external dependencies beyond stdlib
- Work on Ubuntu 24.04 with Python 3.10+
- Fail safely (if any component crashes, the system
  remains in its last known state — never triggers
  lockdown on error)

Do NOT connect these to cron yet. Build and test first.
Show me all three files and run the tests in Docker.
```

### Testing the Dead Man's Switch

```
Create section_9/weapons/S9-W-006_test.py

Test matrix:
1. Heartbeat writes correctly with incrementing sequence
2. Monitor detects fresh heartbeat (no alert)
3. Monitor detects 3 missed heartbeats (WARNING logged)
4. Monitor detects 6 missed heartbeats (ACTIVATION triggered)
5. Lockdown in simulation mode prints correct actions
6. Lockdown with --live flag would execute (test that
   the flag check works, NOT that lockdown executes)
7. Malformed heartbeat.json doesn't trigger false activation
8. Missing heartbeat.json doesn't trigger false activation
   (treats as "never started" not "missed")
9. Race condition: heartbeat writes while monitor reads
   (monitor should handle gracefully)

Run all tests in Docker. Show me results.
Register S9-W-006 in REGISTRY.md as TESTED.
```

-----

## 6. Run the Quarterly Review (WI-006)

Use Claude Code to assist the quarterly review.

### Session Script

```
Read section_9/WORK_INSTRUCTIONS.md WI-006.
Read section_9/operations/LOG.md (full contents).
Read section_9/intelligence/THREATS.md (full contents).
Read section_9/weapons/REGISTRY.md (full contents).

Execute the quarterly review:

1. Operations summary: count operations by threat level
2. Threat landscape: list active/new/neutralized/dismissed
3. Weapons status: count by status (operational, in dev,
   tested, retired)
4. Intelligence retention: identify any routine intel
   older than 90 days that should be purged per the
   Forgetting Law
5. Flag any concerns

Write the quarterly review to:
section_9/operations/REVIEW_[YYYY]_Q[X].md
using the template from WI-006 Step 6.

Show me the review before committing. I will fill in
the budget numbers manually.
```

-----

## 7. Incident Response (WI-007)

When something is actively happening. Speed matters.
Paste this into Claude Code immediately:

```
INCIDENT RESPONSE — READ FAST AND ACT:

Read section_9/WORK_INSTRUCTIONS.md WI-007.
Read section_9/CHARTER.md Section III (authorization matrix).

SITUATION:
[PASTE WHAT IS HAPPENING — one paragraph max]

Execute:
1. Classify: severity and attribution, one line each
2. Containment: what do we do RIGHT NOW to stop damage?
   List specific commands or actions.
3. What weapons do we have operational? Check REGISTRY.md.
4. What's the authorized response level per the matrix?
5. Draft the operations log entry.

Do NOT commit anything yet. Show me your analysis and
wait for my go/no-go.
```

After the incident:

```
Read section_9/WORK_INSTRUCTIONS.md WI-007 post-incident
section.

Write the incident report:
section_9/operations/INCIDENT_[YYYY-MM-DD]_[codename].md

Include: timeline, containment actions taken, weapons
deployed, outcome, lessons learned, new capability gaps
identified.

Also update:
- section_9/intelligence/THREATS.md (new or updated entry)
- section_9/operations/LOG.md (full operation record)
- section_9/weapons/REGISTRY.md (if any weapon status changed)

Show me the full diff.
```

-----

## 8. Parallel Construction Handoff (WI-009)

When Section 9 intelligence needs to reach the Wardens.

```
Read section_9/WORK_INSTRUCTIONS.md WI-009.

I need to prepare a sanitized handoff for threat S9-T-[XXX].

Read the full intelligence file for this threat at:
section_9/intelligence/S9-T-[XXX]_[name]/

Prepare the sanitized brief:
1. State the conclusion (what we believe is true)
2. List ONLY publicly verifiable indicators — things
   the Wardens can find on their own through:
   - Blockchain explorers
   - Public social media
   - GitHub public activity
   - Domain WHOIS records
   - Any other public source
3. Suggest an investigation path using only lawful,
   public methods
4. Strip ALL references to:
   - How Section 9 discovered this
   - Which weapons were used
   - Any honeypot or deception operation details
   - Any internal monitoring details

Write the sanitized brief to:
section_9/operations/HANDOFF_S9-T-[XXX]_sanitized.md

I will review before passing to the Crown → Warden
channel.

Also log the handoff in section_9/operations/LOG.md
per the WI-009 template.

Show me the diff.
```

-----

## 9. Git Workflow for Section 9

### Commit Conventions

| Prefix | Use for |
|--------|---------|
| `sec9:` | All Section 9 changes |
| `sec9-w:` | Weapon-specific changes |
| `sec9-t:` | Threat intelligence updates |
| `sec9-ops:` | Operational log updates |
| `sec9-admin:` | Administrative (budget, review, etc.) |

### Examples

```
sec9: initialize section 9
sec9-w: S9-W-001 tripwire alpha — tested, registered
sec9-t: new threat registered S9-T-001
sec9-ops: Q1 2026 quarterly review
sec9-admin: quarterly budget adjustment
sec9-w: S9-W-006 dead man switch — heartbeat component tested
```

### What NOT to Put in Commit Messages

- Threat actor names or identifiers
- Specific attack details
- Weapon capabilities or techniques
- Intelligence source descriptions
- Anything you wouldn't want in `git log --oneline`
  if someone gained temporary read access

### Branch Strategy

During the Founding Period, everything goes to `main`.
When Section 9 has active operations:

```
main            — stable, reviewed
sec9/dev        — active weapon development
sec9/hotfix     — emergency patches during incidents
```

Merge to main only after Crown review:

```bash
# In Claude Code:
git checkout sec9/dev
# ... do work ...
git checkout main
git merge sec9/dev --no-ff -m "sec9: merge [description]"
git push origin main
```

-----

## 10. Emergency Procedures

### Claude Code Session Crashed During Incident

Restart and paste:

```
RESUMING INCIDENT RESPONSE.
Read section_9/operations/LOG.md — find the most recent
ACTIVE operation.
Read section_9/intelligence/THREATS.md — find the active
threat.
Summarize what was happening and what the next step should be.
```

### Beelink Power Loss / Restart

After reboot:

```bash
# Verify all services
sudo systemctl status docker
ollama list
cd ~/House-Bernard && git status

# Check if Dead Man's Switch heartbeat is current
cat section_9/operations/heartbeat.json

# If heartbeat is stale, manually refresh:
python3 section_9/weapons/S9-W-006_heartbeat.py

# Start Claude Code
claude
```

Then in Claude Code:

```
Run a quick Section 9 status check:
1. Is the heartbeat current? Read operations/heartbeat.json
2. Are there any active threats? Read intelligence/THREATS.md
3. Are all weapons still operational? Read weapons/REGISTRY.md
4. Any pending operations? Read operations/LOG.md for
   ACTIVE status entries
Report status.
```

### Need to Go Dark Immediately

If the repo needs to go private RIGHT NOW:

```bash
# Do NOT use Claude Code for this — too slow
# Go directly to GitHub in browser:
# Settings → General → Danger Zone → Make Private

# Then from terminal:
cd ~/House-Bernard
echo "REPO WENT PRIVATE $(date -Iseconds)" >> section_9/operations/LOG.md
git add -A && git commit -m "sec9-admin: visibility change" && git push
```

-----

## Appendix A: Claude Code Prompt Templates

Copy-paste these as needed. Replace bracketed values.

### Quick Weapon Build

```
Read section_9/CHARTER.md and section_9/weapons/REGISTRY.md.
Build weapon S9-W-[XXX] "[NAME]":
- Class: [I/II/III/IV]
- Purpose: [one line]
- [technical requirements]
Create design doc, code, and tests. Run tests in Docker.
Run security_scanner.py on the code. Update REGISTRY.md.
Show me all diffs.
```

### Quick Threat Entry

```
Read section_9/CHARTER.md Section III.
Register new threat:
- Observed: [what happened]
- When: [timestamp]
- Where: [system/platform]
- Severity: [S1-S4]
- Attribution: [A1-A4]
Create entry in intelligence/THREATS.md and log in
operations/LOG.md. Show diff.
```

### Quick Status Check

```
Section 9 status report:
1. Read operations/heartbeat.json — is it current?
2. Read intelligence/THREATS.md — count active threats
3. Read weapons/REGISTRY.md — count operational weapons
4. Read operations/LOG.md — any ACTIVE operations?
One-paragraph summary.
```

-----

## Appendix B: File Paths Quick Reference

```
~/House-Bernard/
├── CLAUDE.md                              ← Claude Code reads this on start
├── section_9/
│   ├── CHARTER.md                         ← The law
│   ├── README.md                          ← Public-facing (says nothing)
│   ├── WORK_INSTRUCTIONS.md               ← What to do
│   ├── CLAUDE_CODE_INSTRUCTIONS.md        ← How to do it (this file)
│   ├── weapons/
│   │   ├── REGISTRY.md                    ← Weapons inventory
│   │   ├── S9-W-XXX_name.md              ← Design docs
│   │   ├── S9-W-XXX_name.py             ← Weapon code
│   │   ├── S9-W-XXX_test.py             ← Weapon tests
│   │   └── S9-W-XXX_test_results.json   ← Test output
│   ├── operations/
│   │   ├── LOG.md                         ← Append-only audit trail
│   │   ├── heartbeat.json                 ← Dead Man's Switch pulse
│   │   ├── REVIEW_YYYY_QX.md             ← Quarterly reviews
│   │   ├── INCIDENT_YYYY-MM-DD_name.md   ← Incident reports
│   │   └── HANDOFF_S9-T-XXX_sanitized.md ← Parallel construction briefs
│   └── intelligence/
│       ├── THREATS.md                     ← Threat register
│       ├── collection_log.jsonl           ← OSINT collection record
│       ├── osint_monitor.py               ← Automated OSINT script
│       └── S9-T-XXX_name/               ← Per-threat intel folders
│           ├── assessment.md
│           ├── indicators.json
│           ├── collection_log.jsonl
│           └── analysis.md
├── security/
│   └── security_scanner.py                ← Run weapons through this
├── airlock/
│   └── airlock_monitor.py                 ← Log source for Tripwire
└── openclaw/
    └── openclaw.json                      ← Cron jobs configured here
```

-----

*Classification: CROWN EYES ONLY*
*Section 9 — The Sword of the House*
*Ad Astra Per Aspera*
