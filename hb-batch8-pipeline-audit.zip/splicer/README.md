# Splicer - Gene Extraction

Deterministic extraction of allowlisted functions from Python source files. No execution of candidate code. Content-addressed storage.

## What It Does

1. Parses the target `.py` file using Python's AST (no import, no execution)
2. Extracts only top-level functions that match the allowlist
3. Strips docstrings, normalizes whitespace
4. Writes a gene module to content-addressed storage: `genes/<sha256>/gene.py`
5. Writes metadata: `genes/<sha256>/meta.json`

## Usage

```bash
# Extract specific functions from a survivor's mutation.py
python3 splicer.py --source /path/to/mutation.py --out ./genes --allow hb_ingest,hb_compact

# Require at least one function extracted (fail-closed)
python3 splicer.py --source /path/to/mutation.py --out ./genes --allow hb_ingest --require-nonempty
```

## Output

```
genes/
└── <sha256>/
    ├── gene.py       # Extracted function(s), header-stamped
    └── meta.json     # Source file, allowlist, extracted/missing names, hash
```

Gene modules are idempotent: re-extracting the same functions produces the same hash. A hash collision with different content triggers a hard failure (fail-closed).

## SAIF Pipeline Integration

When a survivor passes T0-T4 in the executioner:

1. Survivor `.zip` lands in `~/.openclaw/lab_a/survivors/`
2. Extract `mutation.py` from the archive
3. Run splicer with the allowlist of SAIF functions: `--allow ingest,compact,audit`
4. Gene stored in content-addressed `genes/` directory
5. Register gene in `ledger/GENE_REGISTRY.md`

## Security Properties

- **No execution:** AST parsing only. Candidate code never runs.
- **Allowlist-only:** Only explicitly named functions are extracted. No wildcards.
- **No nested extraction:** Only top-level function definitions. No class methods.
- **Deterministic:** Same input always produces same output hash.
- **Content-addressed:** Storage keyed by SHA-256 of the gene module text.

## Phase 1 (Future)

- Automatic pattern detection across multiple survivors
- Cross-gene comparison for convergent evolution
- Integration with outcome_writer for canonical gene registration

---

*House Bernard — Extract the Law, Not the Exploit*
