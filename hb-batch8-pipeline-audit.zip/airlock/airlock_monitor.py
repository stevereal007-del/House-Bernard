#!/usr/bin/env python3
"""
Airlock Monitor - Lab A Phase 0
Watches inbox, runs security scan, triggers executioner on new SAIF artifacts.

Pipeline: Detect → Sandbox → Security Scan → Executioner
"""

import time
import zipfile
from pathlib import Path
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import subprocess
import shutil


# Resolve paths relative to this script's location in the repo
REPO_ROOT = Path(__file__).resolve().parent.parent
EXECUTIONER = REPO_ROOT / 'executioner' / 'executioner_production.py'
SECURITY_SCANNER = REPO_ROOT / 'security' / 'security_scanner.py'


class AirlockHandler(FileSystemEventHandler):
    def __init__(self):
        self.sandbox = Path.home() / '.openclaw/sandbox'
        self.sandbox.mkdir(parents=True, exist_ok=True)
    
    def _wait_for_stable(self, path: Path, timeout: float = 10.0, interval: float = 1.0) -> bool:
        """Wait until file size is stable (write complete). Returns False on timeout."""
        prev_size = -1
        elapsed = 0.0
        while elapsed < timeout:
            try:
                curr_size = path.stat().st_size
            except OSError:
                return False
            if curr_size == prev_size and curr_size > 0:
                return True
            prev_size = curr_size
            time.sleep(interval)
            elapsed += interval
        return False

    def _security_scan(self, artifact_dir: Path) -> str:
        """
        Run security_scanner.py on extracted artifact.
        Returns verdict: PASS, FLAG, QUARANTINE, or REJECT.
        """
        mutation_py = artifact_dir / 'mutation.py'
        if not mutation_py.exists():
            # No mutation.py = not a valid SAIF artifact, executioner will catch this
            return 'PASS'

        try:
            result = subprocess.run(
                ['python3', str(SECURITY_SCANNER), str(mutation_py)],
                capture_output=True, text=True, timeout=30
            )
            import json
            report = json.loads(result.stdout)
            verdict = report.get('overall_verdict', 'PASS')
            print(f'[AIRLOCK] Security scan: {verdict}')
            if report.get('results'):
                for r in report['results']:
                    s = r.get('summary', {})
                    if s.get('total', 0) > 0:
                        print(f'[AIRLOCK]   {r["file"]}: C={s.get("critical",0)} H={s.get("high",0)} M={s.get("medium",0)} L={s.get("low",0)}')
            return verdict
        except subprocess.TimeoutExpired:
            print('[AIRLOCK] Security scan timeout — treating as REJECT')
            return 'REJECT'
        except Exception as e:
            print(f'[AIRLOCK] Security scan error: {e} — treating as REJECT')
            return 'REJECT'

    def on_created(self, event):
        if event.is_directory:
            return

        artifact = Path(event.src_path)

        # Only process .zip files
        if artifact.suffix != '.zip':
            print(f'[AIRLOCK] Ignoring non-zip: {artifact.name}')
            return

        print(f'[AIRLOCK] New artifact detected: {artifact.name}')

        # Wait for file write to complete before moving
        if not self._wait_for_stable(artifact):
            print(f'[AIRLOCK] File not stable after timeout, skipping: {artifact.name}')
            return

        # Move to sandbox
        dest = self.sandbox / artifact.name
        try:
            shutil.move(str(artifact), str(dest))
            print(f'[AIRLOCK] Moved to sandbox: {dest}')
        except Exception as e:
            print(f'[AIRLOCK] Failed to move: {e}')
            return

        # --- SECURITY SCAN (before executioner) ---
        scan_dir = self.sandbox / artifact.stem
        try:
            with zipfile.ZipFile(dest, 'r') as zf:
                zf.extractall(scan_dir)
        except Exception as e:
            print(f'[AIRLOCK] Failed to extract for scan: {e}')
            # Let executioner handle the bad zip
            scan_dir = None

        if scan_dir is not None:
            # Resolve root (handle single-folder zips)
            children = [
                p for p in scan_dir.iterdir()
                if not p.name.startswith('__MACOSX') and not p.name.startswith('.')
            ]
            saif_root = children[0] if len(children) == 1 and children[0].is_dir() else scan_dir

            scan_verdict = self._security_scan(saif_root)

            # Clean up extracted files (executioner does its own extraction)
            shutil.rmtree(scan_dir, ignore_errors=True)

            if scan_verdict == 'REJECT':
                print(f'[AIRLOCK] {artifact.name} REJECTED by security scanner — not forwarding to executioner')
                # Move to quarantine
                quarantine = Path.home() / '.openclaw/quarantine'
                quarantine.mkdir(parents=True, exist_ok=True)
                try:
                    shutil.move(str(dest), str(quarantine / artifact.name))
                except Exception:
                    pass
                return

            if scan_verdict == 'QUARANTINE':
                print(f'[AIRLOCK] {artifact.name} QUARANTINED — manual review required')
                quarantine = Path.home() / '.openclaw/quarantine'
                quarantine.mkdir(parents=True, exist_ok=True)
                try:
                    shutil.move(str(dest), str(quarantine / artifact.name))
                except Exception:
                    pass
                return

        # --- EXECUTIONER ---
        print(f'[AIRLOCK] Executing harness...')
        try:
            result = subprocess.run([
                'python3',
                str(EXECUTIONER),
                str(dest)
            ], capture_output=True, text=True, timeout=300)
            
            # Extract verdict from output
            output = result.stdout
            if 'VERDICT:' in output:
                verdict = output.split('VERDICT:')[1].split('\n')[0].strip()
                print(f'[AIRLOCK] {artifact.name} → {verdict}')
            else:
                print(f'[AIRLOCK] Execution completed (no verdict found)')
                
        except subprocess.TimeoutExpired:
            print(f'[AIRLOCK] Timeout (>5min) - killing test')
        except Exception as e:
            print(f'[AIRLOCK] Execution error: {e}')


def main():
    import sys
    
    if not EXECUTIONER.exists():
        print(f'Error: Executioner not found at {EXECUTIONER}')
        print(f'Expected location relative to repo: executioner/executioner_production.py')
        sys.exit(1)

    if not SECURITY_SCANNER.exists():
        print(f'Warning: Security scanner not found at {SECURITY_SCANNER}')
        print(f'Artifacts will proceed to executioner without pre-scan.')
    
    # Inbox directory
    inbox = Path.home() / '.openclaw/inbox'
    inbox.mkdir(parents=True, exist_ok=True)
    
    print('='*60)
    print('AIRLOCK MONITOR - Lab A Phase 0')
    print('='*60)
    print(f'Watching: {inbox}')
    print(f'Security Scanner: {SECURITY_SCANNER}')
    print(f'Executioner: {EXECUTIONER}')
    print('Pipeline: Detect → Sandbox → Security Scan → Executioner')
    print('Waiting for SAIF artifacts (.zip files)...')
    print('='*60)
    
    # Start watching
    observer = Observer()
    handler = AirlockHandler()
    observer.schedule(handler, str(inbox), recursive=False)
    observer.start()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print('\n[AIRLOCK] Shutting down...')
        observer.stop()
    
    observer.join()


if __name__ == '__main__':
    main()
