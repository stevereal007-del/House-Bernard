# BATCH 8 FINDINGS — Full Pipeline + Support Systems Audit

**Auditor:** Claude (Bernardian Council)  
**Date:** 2026-02-08  
**Scope:** airlock/, executioner/, splicer/, ledger/, security/, lab_b/, .gitignore  
**Files audited:** 18 files, ~2,150 lines  

---

## Summary

| Severity | Count |
|----------|-------|
| HIGH | 1 |
| MEDIUM | 5 |
| LOW | 5 |
| ADVISORY | 2 |
| **Total findings** | **13** |
| **Files CLEAN** | executioner_production.py (code logic), splicer.py, security_scanner.py, outcome_writer.py, CLASSES.md, seccomp_lab_a.json, HB_OUTCOME_SCHEMA_V1.json |

---

## HIGH

### F1: Lab B Seccomp Profile Allows Instead of Denying (seccomp_lab_b.json)

**File:** `security/seccomp_lab_b.json`  
**Lines:** Network block (line ~30), Process block (line ~40)

**Bug:** Comments say "LOG and DENY" but the action `SCMP_ACT_LOG` *allows the syscall and logs it*. It does NOT deny.

Network syscalls (socket, connect, bind, etc.) and process creation (clone, fork, execve, ptrace) are all **permitted** under the current profile. An artifact running in Lab B can:
- Open network connections
- Fork processes
- Call execve to spawn shells
- Use ptrace for process injection

**Impact:** Lab B is supposed to observe escape *attempts*, not *successes*. As written, artifacts have nearly full syscall access.

**Fix:** Change network and process blocks from `SCMP_ACT_LOG` to `SCMP_ACT_ERRNO` with `errnoRet: 1`. If you want logging, enable audit logging at the Docker/auditd level separately, or use `SCMP_ACT_TRACE` with a tracer. The current setup is a security gap.

**Note:** This is mitigated IF Lab B containers are always launched with Docker `--network=none` and `--pids-limit`. But the seccomp profile itself should not rely on Docker flags for safety — defense in depth means each layer blocks independently.

---

## MEDIUM

### F2: Airlock Skips Security Scanner (airlock_monitor.py)

**File:** `airlock/airlock_monitor.py`  
**Lines:** 66-80 (on_created → executioner)

**Bug:** Airlock feeds artifacts directly to the executioner without running `security_scanner.py` first. DEFENSE.md states: "they pass through three layers of defense: VirusTotal Code Insight scan, House Bernard's own security_scanner.py, and the Executioner's Docker sandbox." But the airlock only does step 3.

**Pipeline should be:** Airlock → unzip → security_scanner.py on mutation.py → if PASS/FLAG continue → executioner  
**Pipeline is:** Airlock → executioner

**Fix:** Add a security scan step in `AirlockHandler.on_created()` between the sandbox move and the executioner call. Extract the zip, run `security_scanner.py` on the mutation.py file, and only proceed to executioner if the verdict is not REJECT.

### F3: Executioner Doesn't Apply Seccomp Profiles (executioner_production.py)

**File:** `executioner/executioner_production.py`  
**Lines:** 267-283 (_docker_base)

**Bug:** Two seccomp profiles exist in `security/` — `seccomp_lab_a.json` (standard lockdown) and `seccomp_lab_b.json` (permissive logging). But the executioner's Docker invocation doesn't apply either. It only uses:
- `--security-opt no-new-privileges`
- `--cap-drop=ALL`
- `--network=none`
- `--read-only`

The seccomp profiles add protection against syscalls that Docker's default profile may allow (specific filesystem mounts, kernel module loading, ptrace). Without them, the sandbox relies solely on Docker's built-in seccomp defaults.

**Fix:** Add `--security-opt seccomp=/path/to/security/seccomp_lab_a.json` to `_docker_base()`. The path should be resolved relative to the repo root or passed via config.

### F4: Verdict String Mismatch — Executioner vs Outcome Writer

**Bug:** Two naming conventions exist for the same events:

| Event | Executioner verdict | Outcome writer class |
|-------|-------------------|---------------------|
| T0 fail | `KILLED_T0_SELFTEST` | `HARNESS_FAIL_T0` |
| T1 fail | `KILLED_T1_SYNTAX` | `HARNESS_FAIL_T1` |
| T2 fail | `KILLED_T2_DEGRADATION` | `HARNESS_FAIL_T2` |
| T3 fail | `KILLED_T3_COMPACTION` | `HARNESS_FAIL_T3` |
| T4 fail | `KILLED_T4_RESTART` | `HARNESS_FAIL_T4` |
| Invalid zip | `KILLED_INVALID_ZIP` | `FORMAT_INVALID` |
| Invalid SAIF | `KILLED_INVALID_SAIF` | `MANIFEST_INVALID` or `FORMAT_INVALID` |

Neither system is wrong on its own, but when outcome_writer is integrated (it isn't yet — see F10), there will be a translation layer needed. This should be designed now, not discovered during integration.

**Fix:** Add a mapping dict in outcome_writer.py: `EXECUTIONER_TO_HB_CLASS` that translates executioner verdicts to canonical classes. Or, standardize the executioner's verdict strings to match CANONICAL_CLASSES directly.

### F5: HB_STATE Paths Reference Nonexistent Directories

**File:** `ledger/HB_STATE.json`  
**Lines:** paths section

**Bug:** Six paths listed in HB_STATE don't exist in the repo:
- `genes_dir: genes` — splicer output; never created
- `results_dir: results` — runtime; ambiguous (executioner uses `~/.openclaw/lab_a/results/`, not `./results/`)
- `inbox_dir: inbox` — runtime; executioner uses `~/.openclaw/inbox/`
- `purgatory_dir: purgatory` — referenced nowhere in code
- `quarantine_dir: quarantine` — referenced nowhere in code
- `nullsink_dir: nullsink` — referenced nowhere in code

**Impact:** These paths create confusion about where runtime data lives. Code uses `~/.openclaw/` hardcoded paths, but HB_STATE implies they're relative to repo root.

**Fix (two options):**
- **Option A:** Change HB_STATE paths to reflect actual runtime locations (`~/.openclaw/inbox`, etc.) and add a comment distinguishing repo paths from runtime paths.
- **Option B:** Create `genes/` with `.gitkeep` in the repo, and add comments to HB_STATE documenting which paths are "runtime-only" (created by the agent at `~/.openclaw/`).

### F6: Treasury Directory Missing from HB_STATE Paths

**File:** `ledger/HB_STATE.json`

**Bug:** `treasury/` is a real directory with 7 active files (treasury_engine.py, treasury_cli.py, monthly_ops.py, etc.) but isn't listed in HB_STATE's paths section. Every other code directory is listed.

**Fix:** Add `"treasury_dir": "treasury"` to the paths section.

---

## LOW

### F7: Splicer README Outdated

**File:** `splicer/README.md`

**Bug:** README describes Phase 0 as "manual extraction" with a 6-step human process (read code, identify pattern, document as gene). But `splicer.py` v0.2 already implements automated AST-based extraction with content-addressed storage. The README makes it sound like splicer is a placeholder when it's actually functional code.

Also: "Coming Soon: splicer_auto.py" — this is essentially what splicer.py already is.

**Fix:** Rewrite splicer/README.md to document the actual splicer.py capabilities: CLI usage, allowlist-based extraction, content-addressed output, and the gene module format.

### F8: Airlock Service File Template Error

**File:** `airlock/airlock.service`  
**Line:** `User=%i`

**Bug:** `%i` is the systemd template instance name (from `service@instance.service`). Since the file is named `airlock.service` (not `airlock@.service`), `%i` resolves to an empty string, which means the service runs as root.

**Fix:** Change `User=%i` to the actual username (e.g., `User=claude` or `User=helios`), or document that this needs to be edited before installation.

### F9: Airlock Hardcoded Executioner Path

**File:** `airlock/airlock_monitor.py`  
**Line 90:** `executioner_path = Path.home() / 'House-Bernard/executioner/executioner_production.py'`

**Bug:** Path is hardcoded to `~/House-Bernard/`. If the repo is cloned elsewhere, airlock breaks silently.

**Fix:** Accept `--executioner` CLI argument, or resolve relative to the script's own location (`Path(__file__).resolve().parent.parent / 'executioner/executioner_production.py'`).

### F10: No Outcome Writer Integration

**Bug:** `outcome_writer.py` is a standalone module that nothing calls. Neither airlock nor executioner writes canonical HB_OUTCOME_V1 records. The executioner writes its own format to ELIMINATION_LOG.jsonl / SURVIVOR_LOG.jsonl.

**Impact:** Low — this is Phase 0 and integration is planned. But it means the canonical outcome format defined in the schema is untested in the actual pipeline.

**Fix:** Defer to Phase 1, but note that the executioner should eventually call outcome_writer after each verdict. The F4 mapping will be needed at that point.

### F11: .gitignore results/ Pattern Is Unanchored

**File:** `.gitignore`  
**Line:** `results/`

**Bug:** The pattern `results/` matches at any directory depth. This means `lab_b/results/` is also ignored. The `.gitkeep` in `lab_b/results/` was presumably force-added, but any runtime data (INTENT_LOG.jsonl, ESCAPE_LOG.jsonl) would be silently ignored if someone tried to track it.

**Impact:** Low — runtime data shouldn't be in the repo anyway. But the unanchored pattern could surprise someone.

**Fix:** Either anchor the pattern to the root (`/results/`) or leave as-is with an inline comment explaining it's intentional.

---

## ADVISORY (no fix needed)

### A1: Executioner SAIF_RUNNER Escaping — Verified Correct

The double-escaped `\\n` in the SAIF_RUNNER string was investigated. The escaping chain is:
1. `\\n` in triple-quoted string → literal `\n` text in Python string
2. Written to runner.py file → file contains `"\n"` in source
3. Python executes runner.py → interprets `"\n"` as newline character

This is correct. JSONL entries will be properly newline-separated.

### A2: security_scanner.py Bans open() — Verified Correct

The `open()` ban could seem like a false-positive risk for SAIF artifacts that need to read/write state. But the architecture is properly designed: the SAIF_RUNNER (not the artifact's mutation.py) handles all file I/O. The artifact's functions receive state/lineage as arguments and return new state. Artifacts should never call `open()` directly.

---

## Code Quality Notes (not findings)

**executioner_production.py** — Excellent engineering. Deterministic test schedules, proper Docker isolation, fail-closed on every path, content-addressed deduplication via failure fingerprints, clean separation between validation/testing/bookkeeping. The SAIF contract is well-defined and frozen.

**splicer.py** — Best code in the repo. Pure AST extraction without executing candidate code. Content-addressed storage with collision detection. Deterministic I/O with explicit encoding and newline normalization. This is exactly how gene extraction should work.

**security_scanner.py** — Solid static analysis. Good severity hierarchy, proper verdict escalation, and the banned function/import/attribute lists are well-chosen. The async function detection is a nice touch.

**outcome_writer.py** — Clean canonical format with path traversal protection and vocabulary enforcement. Ready for integration.

**seccomp_lab_a.json** — Proper lockdown. Silent deny on everything not whitelisted, explicit blocks on network/process/privilege syscalls.

---

## Audit Completion Status

| File/Directory | Status |
|---|---|
| README.md | ✅ Fixed (Batch 2) |
| PHILOSOPHY.md | ✅ Clean (Batch 2) |
| COUNCIL.md | ✅ Clean (Batch 2) |
| TREASURY.md | ✅ Fixed (Batch 1) |
| ROYALTIES.md | ✅ Fixed (Batch 3) |
| DEFENSE.md | ✅ Clean + updated (Batch 7) |
| QUICKSTART.md | ✅ Clean (Batch 7) |
| openclaw/ | ✅ Rewritten (Batch 7) |
| infrastructure/ | ✅ Rewritten (Batch 7) |
| treasury/ | ✅ Done (Batch 1) |
| .gitignore | ✅ Audited (this batch) — 1 low finding |
| airlock/ | ✅ Audited (this batch) — 1 medium, 2 low |
| executioner/ | ✅ Audited (this batch) — 2 medium, code logic clean |
| splicer/ | ✅ Audited (this batch) — 1 low (README only) |
| ledger/ | ✅ Audited (this batch) — 2 medium |
| security/ | ✅ Audited (this batch) — 1 high, code clean |
| lab_b/ | ✅ Audited (this batch) — code clean |

**THE FULL REPO HAS BEEN AUDITED.**

---

*House Bernard — Trust Nothing, Verify Everything*
